export default function VideoIntro() {
  return (
    <section className="relative min-h-[400px] lg:min-h-[800px] overflow-hidden bg-black flex items-center">
      <img
        src="/image-man-with-laptop.png"
        alt=""
        className="absolute inset-0 w-full h-full object-cover opacity-90"
        style={{ objectPosition: '30% 55%' }}
      />
      <div className="absolute inset-0 bg-black/0"></div>
      <div className="absolute inset-x-0 top-0 h-20 sm:inset-0 sm:h-auto bg-gradient-to-b from-black via-black/10 to-transparent"></div>
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
        <div className="flex flex-col items-center justify-center text-center gap-12"></div>
      </div>
    </section>
  );
}
