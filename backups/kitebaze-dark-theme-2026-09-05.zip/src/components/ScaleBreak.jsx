import { useEffect, useRef, useState } from 'react';

export default function ScaleBreak() {
  const sectionRef = useRef(null);
  const [animateNow, setAnimateNow] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => setAnimateNow(true), 800);
            observer.unobserve(section);
          }
        });
      },
      { threshold: 0.35 },
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`sm:pb-0 sm:pt-24 bg-black border-zinc-900/50 border-b pt-24 pb-0 relative scale-break-section ${animateNow ? 'animate-now' : ''}`}
    >
      <div className="text-center max-w-7xl mr-auto mb-4 ml-auto">
        <h2 className="md:text-6xl text-4xl font-medium text-white tracking-tight font-space-grotesk mt-6 mb-6">
          Everything works. Until it
          <span className="inline-flex align-bottom text-[#FE4C00] mx-1 relative">
            <span className="invisible" aria-hidden="true">doesn't</span>
            <span className="split-word-top [clip-path:polygon(0_0,100%_0,100%_50%,0_50%)] font-medium font-space-grotesk w-full h-full absolute top-0 left-0 text-[#FE4C00]">breaks</span>
            <span className="split-word-line text-[#FE4C00] bg-white w-full h-[2px] rounded-full absolute top-1/2 left-0 shadow-[0_0_8px_rgba(255,255,255,0.8)]"></span>
            <span className="split-word-bottom [clip-path:polygon(0_50%,100%_50%,100%_100%,0_100%)] font-medium text-[#FE4C00] w-full h-full absolute top-0 left-0">breaks</span>
          </span>
        </h2>
        <p className="text-lg sm:text-2xl font-light text-white font-inter">
          Every tool does its job. Then the work stops at the edge of it, waiting for a person to carry it to the next one. No system owns that part. So it lives in someone's memory.
        </p>
      </div>
    </section>
  );
}
