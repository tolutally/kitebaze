import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import LogoMark from './LogoMark.jsx';

export default function Header() {
  const [solutionsOpen, setSolutionsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSolutionsOpen, setMobileSolutionsOpen] = useState(false);
  const solutionsRef = useRef(null);

  useEffect(() => {
    function onDocClick(event) {
      if (solutionsRef.current && !solutionsRef.current.contains(event.target)) {
        setSolutionsOpen(false);
      }
    }
    document.addEventListener('click', onDocClick);
    return () => document.removeEventListener('click', onDocClick);
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-zinc-900/50 bg-black/50 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-32 items-center justify-between">
          <Link to="/" className="flex flex-shrink-0 items-center gap-3" aria-label="KiteBaze home">
            <LogoMark />
            <span className="flex flex-col font-space-grotesk text-xl font-semibold leading-[0.82] tracking-tight text-white uppercase" aria-hidden="true">
              <span>KITE</span>
              <span>BAZE</span>
            </span>
          </Link>
          <div className="flex items-center gap-8">
            <nav className="hidden md:flex font-inter gap-x-8 items-center">
              <div className="relative" ref={solutionsRef}>
                <button
                  type="button"
                  className="flex items-center gap-2 hover:text-white transition-colors text-base font-normal text-zinc-400"
                  onClick={(event) => {
                    event.stopPropagation();
                    setSolutionsOpen((open) => !open);
                  }}
                >
                  Solutions
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    className={`transition-transform duration-200 ${solutionsOpen ? 'rotate-180' : ''}`}
                  >
                    <path d="m6 9 6 6 6-6"></path>
                  </svg>
                </button>
                <div
                  className={`${solutionsOpen ? '' : 'hidden'} absolute left-0 top-full mt-4 w-60 rounded-2xl border border-white/10 bg-black/60 backdrop-blur-xl shadow-2xl shadow-black/40 overflow-hidden z-50`}
                  onClick={(event) => event.stopPropagation()}
                >
                  <Link to="/workflow-build" className="block px-5 py-4 text-sm text-zinc-300 hover:text-white hover:bg-white/10 transition-colors">Workflow Build</Link>
                  <Link to="/bottleneck" className="block px-5 py-4 text-sm text-zinc-300 hover:text-white hover:bg-white/10 transition-colors border-t border-white/10">Bottleneck</Link>
                </div>
              </div>
              <Link to="/about-us" className="hover:text-white transition-colors text-base font-normal text-zinc-400">About Us</Link>
              <Link to="/case-studies" className="hover:text-white transition-colors text-base font-normal text-zinc-400">Case Studies</Link>
            </nav>
            <Link to="/contact-form" className="hidden md:inline-flex items-center justify-center hover:bg-zinc-900 transition-colors sm:w-auto text-sm font-normal text-white font-inter bg-[#FE4C00] rounded-full pt-3.5 pr-8 pb-3.5 pl-8">
              Get in Touch
            </Link>
            <button
              type="button"
              className="md:hidden flex flex-col gap-1.5 p-2"
              aria-label="Open menu"
              onClick={() => setMobileMenuOpen((open) => !open)}
            >
              <span
                className="block w-6 h-0.5 bg-white transition-all duration-300"
                style={mobileMenuOpen ? { transform: 'translateY(8px) rotate(45deg)' } : undefined}
              ></span>
              <span
                className="block w-6 h-0.5 bg-white transition-all duration-300"
                style={mobileMenuOpen ? { opacity: 0 } : undefined}
              ></span>
              <span
                className="block w-6 h-0.5 bg-white transition-all duration-300"
                style={mobileMenuOpen ? { transform: 'translateY(-8px) rotate(-45deg)' } : undefined}
              ></span>
            </button>
          </div>
        </div>
      </div>
      <div className={`${mobileMenuOpen ? '' : 'hidden'} md:hidden bg-black/95 backdrop-blur-xl border-t border-zinc-800`}>
        <nav className="flex flex-col px-6 py-6 gap-5 font-inter">
          <div>
            <button
              type="button"
              className="flex items-center justify-between w-full text-zinc-300 hover:text-white transition-colors text-base"
              onClick={() => setMobileSolutionsOpen((open) => !open)}
            >
              Solutions
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className={`transition-transform duration-200 ${mobileSolutionsOpen ? 'rotate-180' : ''}`}
              >
                <path d="m6 9 6 6 6-6"></path>
              </svg>
            </button>
            <div className={`${mobileSolutionsOpen ? 'flex' : 'hidden'} flex-col gap-2 mt-3 pl-4 border-l border-zinc-800`}>
              <Link to="/workflow-build" className="text-zinc-400 hover:text-white transition-colors text-sm py-1">Workflow Build</Link>
              <Link to="/bottleneck" className="text-zinc-400 hover:text-white transition-colors text-sm py-1">Bottleneck</Link>
            </div>
          </div>
          <Link to="/about-us" className="text-zinc-300 hover:text-white transition-colors text-base">About Us</Link>
          <Link to="/case-studies" className="text-zinc-300 hover:text-white transition-colors text-base">Case Studies</Link>
          <Link to="/contact-form" className="inline-flex items-center justify-center text-sm font-normal text-white bg-[#FE4C00] rounded-full py-3.5 px-8 mt-2">
            Get in Touch
          </Link>
        </nav>
      </div>
    </header>
  );
}
