export default function WhyKitebaze() {
  return (
    <section className="bg-black border-zinc-900 border-t pt-24 pb-24">
      <div className="sm:px-6 lg:px-8 max-w-7xl mr-auto ml-auto pr-4 pl-4">
        <div className="fade-up-element flex flex-col sm:flex-row sm:items-end gap-6 z-40 mb-16 relative gap-x-6 gap-y-6 items-start justify-between">
          <div>
            <h2 className="sm:text-6xl text-4xl font-medium text-white tracking-tight font-grotesk mb-4">Why Kitebaze?</h2>
            <p className="sm:text-xl text-base font-light text-zinc-400">Businesses where the client list is the business. Outcomes over theory.</p>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="flex flex-col gap-4">
            <div className="flex-1 sm:p-8 flex fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 w-[70px] h-[70px]" style={{ color: 'rgb(254, 76, 0)' }}>
                <path d="M5 7v11a1 1 0 0 0 1 1h11"></path>
                <path d="M5.293 18.707 11 13"></path>
                <circle cx="19" cy="19" r="2"></circle>
                <circle cx="5" cy="5" r="2"></circle>
              </svg>
              <p className="leading-tight text-lg sm:text-xl font-bold text-white font-sans">Builds on the software you already run. Nothing to migrate, nothing to retrain, no subscription to add.</p>
            </div>
            <div className="flex-1 sm:p-8 flex gap-6 fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
              <span className="text-6xl sm:text-8xl font-bold text-[#FE4C00] tracking-tight font-inter">37</span>
              <p className="leading-tight text-base sm:text-xl font-light text-white font-inter">Years of combined team experience from startup to scale</p>
            </div>
            <div className="flex-1 sm:p-8 flex gap-6 fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
              <p className="leading-tight text-lg sm:text-2xl font-bold text-[#FE4C00] font-inter">We don't sell advice. We develop working systems.</p>
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden min-h-[400px] lg:min-h-full fade-up-element group border border-zinc-800/50">
            <img
              src="/recovered-assets/8d348428-4a26-439e-9abe-73272d1bc0a8_1600w.png"
              alt="Vintage and Modern Cars in Residential Garage"
              className="w-full h-full object-cover absolute inset-0 transition-transform duration-1000 group-hover:scale-105"
            />
            <div className="transition-opacity duration-1000 group-hover:bg-black/20 bg-black/40 absolute top-0 right-0 bottom-0 left-0"></div>
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div
                className="w-40 h-40 bg-[#FE4C00] animate-[spin_12s_linear_infinite]"
                style={{
                  WebkitMask: "url('/recovered-assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png') center/contain no-repeat",
                  mask: "url('/recovered-assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png') center/contain no-repeat",
                }}
              ></div>
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <div className="flex-1 flex fade-up-element min-h-[140px] sm:p-8 bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
              <p className="leading-tight text-base sm:text-xl font-light text-white font-inter">Service operations with people in the field</p>
              <span className="text-6xl sm:text-8xl font-bold text-[#FE4C00] tracking-tight font-inter">$12B</span>
            </div>
            <div className="flex-1 sm:p-8 flex gap-6 fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 w-[70px] h-[70px]" style={{ color: 'rgb(254, 76, 0)' }}>
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path>
                <path d="M12 18V6"></path>
              </svg>
              <p className="leading-tight text-lg sm:text-2xl font-bold text-white font-inter">Owner-led businesses that outgrew the workaround</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
