import { Link } from 'react-router-dom';
import LogoMark from './LogoMark.jsx';

export default function Footer() {
  return (
    <footer className="bg-black z-40 border-zinc-900 border-t pt-20 pb-10 relative">
      <div className="sm:px-6 lg:px-8 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-8 mb-16 gap-x-12 gap-y-12">
          <div className="md:col-span-6 lg:col-span-5">
            <Link to="/" className="flex items-center gap-3 mb-8 w-fit" aria-label="Kitebaze home">
              <LogoMark width={40} height={47} />
              <span className="flex flex-col font-space-grotesk text-xl font-semibold leading-[0.82] tracking-tight text-white uppercase">
                <span>KITE</span>
                <span>BAZE</span>
              </span>
            </Link>
            <div className="flex flex-col gap-6 w-full font-sans mt-2">
              <p className="leading-relaxed text-base font-light text-zinc-100 font-inter max-w-md">Useful ways to automate the work behind your business.</p>
              <form action="https://formspree.io/f/xwvdplkk" method="POST" className="flex w-full max-w-[400px] mt-2">
                <input type="hidden" name="_subject" value="New Newsletter Signup" />
                <input type="email" name="email" placeholder="Email Address" required className="flex-1 h-12 bg-white text-zinc-900 placeholder:text-zinc-400 placeholder:font-mono font-mono px-4 text-sm outline-none min-w-0 rounded-none border-none" />
                <button type="submit" className="hover:bg-[#e64400] transition-colors whitespace-nowrap border-none focus:outline-none text-sm font-medium text-black font-inter bg-[#FE4C00] h-12 rounded-none pr-6 pl-6 cursor-pointer">SIGN-UP</button>
              </form>
            </div>
          </div>
          <div className="md:col-span-3 lg:col-span-2 lg:col-start-8 font-inter">
            <h4 className="font-sans text-white text-lg font-normal mb-8">Social</h4>
            <ul className="space-y-5">
              <li><a href="https://x.com/Kitebaze" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">X</a></li>
              <li><a href="https://www.facebook.com/kitebaze/" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">Facebook</a></li>
              <li><a href="https://www.youtube.com/@Kitebaze" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">YouTube</a></li>
              <li><a href="https://www.linkedin.com/company/kitebaze/" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">LinkedIn</a></li>
              <li><a href="https://www.instagram.com/kitebaze/" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">Instagram</a></li>
            </ul>
          </div>
          <div className="md:col-span-3 lg:col-span-3">
            <h4 className="text-lg font-normal text-white font-inter mb-8">Get in touch</h4>
            <p className="leading-relaxed text-base font-light text-zinc-400 font-inter max-w-[280px] mb-8">Your business doesn't need more software.<br />It needs less manual work.</p>
            <a href="mailto:hello@kitebaze.com" className="inline-flex items-center justify-center hover:bg-[#e64400] transition-colors hover:shadow-[0_0_30px_rgba(254,76,0,0.5)] text-sm font-normal text-white bg-[#FE4C00] rounded-full pt-3 pr-6 pb-3 pl-6 shadow-[0_0_20px_rgba(254,76,0,0.3)]">Email us Here</a>
          </div>
        </div>
        <div className="pt-8 border-t border-zinc-900/80 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm font-light text-zinc-500">© 2026 Kitebaze. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-zinc-500 hover:text-zinc-300 font-light text-sm transition-colors">Privacy Policy</a>
            <a href="#" className="text-zinc-500 hover:text-zinc-300 font-light text-sm transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
