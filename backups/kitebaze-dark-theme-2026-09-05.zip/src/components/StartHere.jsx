import { Link } from 'react-router-dom';

export default function StartHere() {
  return (
    <section className="sm:py-32 bg-black z-10 pt-12 pb-16 relative">
      <div className="sm:px-6 lg:px-8 max-w-6xl mx-auto pr-8 pl-8">
        <div className="flex flex-row items-center justify-between mb-8 sm:mb-16 gap-4">
          <h2 className="md:text-7xl text-4xl font-medium text-white tracking-tight font-space-grotesk m-0" style={{ animation: 'slideInY 800ms ease-in-out 0ms forwards' }}>Start Here</h2>
          <button
            type="button"
            className="hover:bg-[#CC0000] transition-all duration-300 cursor-pointer whitespace-nowrap text-sm sm:text-base font-medium text-white bg-[#FE4C00] w-fit rounded-full px-5 sm:px-8 py-3.5"
            onClick={() => { window.location.href = 'https://calendly.com/kindling-solutions/kindling-solutions'; }}
          >
            Show Us Your Workflow
          </button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 lg:gap-10 gap-x-8 gap-y-8 items-stretch">
          <div className="flex h-full">
            <Link
              to="/workflow-build"
              onClick={() => { history.scrollRestoration = 'manual'; window.scrollTo(0, 0); }}
              style={{ boxShadow: '0 0 60px 10px rgba(254,76,0,0.3), 0 0 120px 20px rgba(255,255,255,0.06)', textDecoration: 'none' }}
              className="sm:p-12 flex flex-col z-10 transition-all duration-300 hover:scale-[1.02] w-full h-full rounded-3xl pt-8 pr-8 pb-8 pl-8 relative overflow-hidden bg-black"
            >
              <div className="bg-center bg-[url('/recovered-assets/photo-1595418917831-ef942bd9f9ec.jpg')] bg-cover absolute top-0 right-0 bottom-0 left-0"></div>
              <div className="relative z-10">
                <div className="flex-grow flex flex-col">
                  <div className="flex items-center gap-3 mb-16">
                    <p className="leading-tight sm:text-4xl text-2xl font-medium text-[#FE4C00] tracking-tight font-inter">
                      Workflow Build
                    </p>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{ color: 'rgb(255, 255, 255)' }}>
                      <path d="M5 12h14"></path>
                      <path d="m12 5 7 7-7 7"></path>
                    </svg>
                  </div>
                  <p className="leading-tight sm:text-3xl text-xl font-normal text-white tracking-tight font-inter mb-8">Want the whole process fixed, not patched?</p>
                  <p className="sm:text-xl leading-tight text-base font-normal text-white tracking-tight font-inter mb-8">We map one process end to end and rebuild how information moves through it. Intake. Quote. Scheduling. Documentation. Invoicing. Follow-up.</p>
                </div>
              </div>
            </Link>
          </div>
          <div className="flex flex-col h-full">
            <Link
              to="/bottleneck"
              onClick={() => { history.scrollRestoration = 'manual'; window.scrollTo(0, 0); }}
              style={{ boxShadow: '0 0 60px 10px rgba(254,76,0,0.3), 0 0 120px 20px rgba(255,255,255,0.06)', textDecoration: 'none' }}
              className="sm:p-10 flex flex-col h-full transition-all duration-300 hover:scale-[1.02] bg-center bg-zinc-800 bg-[url('/recovered-assets/photo-1595418917831-ef942bd9f9ec.jpg')] bg-cover rounded-3xl pt-8 pr-8 pb-8 pl-8 relative"
            >
              <div className="flex items-center gap-3 mb-16">
                <p className="leading-tight sm:text-4xl text-2xl font-medium text-[#FE4C00] tracking-tight font-inter">
                  One Bottleneck
                </p>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{ color: 'rgb(255, 255, 255)' }}>
                  <path d="M5 12h14"></path>
                  <path d="m12 5 7 7-7 7"></path>
                </svg>
              </div>
              <div>
                <p className="sm:text-3xl leading-snug text-xl font-normal text-white font-inter mb-8">Fix one thing first. Judge us on that.</p>
                <p className="sm:text-xl leading-tight text-base font-normal text-white tracking-tight font-inter">We automate one defined problem, connect it to the tools involved, and prove it works before touching anything else.</p>
                <div className="mt-10 px-2 flex flex-col items-start"></div>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
