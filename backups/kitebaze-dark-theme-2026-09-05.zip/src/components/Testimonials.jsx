import useTestimonialScroll from '../hooks/useTestimonialScroll.js';

export default function Testimonials() {
  useTestimonialScroll();

  return (
    <section className="bg-zinc-950/50 border-zinc-900 border-t pt-24 pb-4 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="fade-up-element flex flex-col sm:flex-row sm:items-end gap-6 z-40 mb-16 relative gap-x-6 gap-y-6 items-start justify-between">
          <div>
            <h2 className="sm:text-6xl text-4xl font-medium text-[#FE4C00] tracking-tight font-grotesk mb-4">If your business sounds like this,</h2>
            <h2 className="sm:text-6xl text-4xl font-medium text-white tracking-tight font-grotesk mb-4">we should talk.</h2>
            <p className="text-base sm:text-lg text-zinc-400 font-light">The spreadsheet is still running half the operation.</p>
          </div>
        </div>
        <div className="flex flex-col sm:gap-24 pb-[5vh] relative gap-x-12 gap-y-12">
          <div className="testimonial-sticky sticky top-24 z-10 w-full">
            <div className="testimonial-inner w-full relative z-10" style={{ filter: 'brightness(1)' }}>
              <div className="absolute -top-16 -left-10 sm:-top-24 sm:-left-20 w-[300px] h-[300px] sm:w-[500px] sm:h-[500px] bg-[#FE4C00] rounded-full blur-[100px] sm:blur-[120px] opacity-30 pointer-events-none z-0"></div>
              <div className="absolute -bottom-12 right-6 sm:-bottom-20 sm:right-16 w-48 sm:w-[280px] z-0 pointer-events-none drop-shadow-[0_10px_30px_rgba(254,76,0,0.2)] translate-y-[20%]">
                <img src="/recovered-assets/5782a90f-3351-458e-b20b-e4b0a099d529_800w.png" alt="Orange Quote Marks" className="w-full h-auto opacity-100" />
              </div>
              <div className="absolute inset-0 bg-zinc-950/60 backdrop-blur-[60px] rounded-3xl sm:rounded-[2rem] border border-zinc-700/50 shadow-2xl z-10"></div>
              <div className="sm:p-12 flex flex-col sm:gap-14 z-20 pt-8 pr-8 pb-8 pl-8 relative gap-x-10 gap-y-10">
                <div className="flex items-center justify-between w-full">
                  <span className="font-grotesk text-[#FE4C00] text-sm font-semibold uppercase tracking-widest">Client's Testimonial</span>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-12 lg:gap-16 gap-x-10 gap-y-10">
                  <div className="lg:col-span-4 flex flex-col h-full">
                    <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-start gap-6 sm:gap-8">
                      <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden flex-shrink-0 border border-zinc-800">
                        <img src="/recovered-assets/e0c9e981-4181-4858-920f-e00abb098e87_320w.jpg" alt="Chris Stevenson" className="w-full h-full object-cover grayscale" />
                      </div>
                      <div className="flex flex-col gap-1">
                        <h3 className="sm:text-4xl leading-none text-2xl font-medium text-[#FE4C00] tracking-tight font-grotesk">Chris Stevenson</h3>
                        <span className="sm:text-lg sm:mt-2 text-sm font-light text-white font-sans mt-1">Founder &amp; Creative Director, Black Sheep Creative</span>
                      </div>
                    </div>
                  </div>
                  <div className="lg:col-span-8 flex flex-col sm:gap-12 sm:pb-0 pb-8 gap-x-8 gap-y-8">
                    <div className="flex flex-col gap-6 max-w-2xl font-light">
                      <p className="leading-relaxed text-xl text-zinc-300 font-sans sm:text-2xl">
                        "We already pay for the software. But the spreadsheet is still running half the operation."
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="testimonial-sticky sticky top-32 z-20 w-full">
            <div className="testimonial-inner grid grid-cols-1 md:grid-cols-2 lg:gap-12 w-full backdrop-blur gap-x-8 gap-y-8" style={{ filter: 'brightness(1)' }}>
              <div className="group h-full">
                <div className="sm:p-10 group-hover:border-zinc-700 transition-colors flex flex-col bg-zinc-900/60 h-full border-zinc-800/80 border rounded-2xl px-8 py-8 relative shadow-2xl backdrop-blur-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-10 h-10 text-zinc-700 mb-6">
                    <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path>
                    <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
                  </svg>
                  <p className="sm:text-2xl leading-relaxed flex-grow text-xl font-light text-zinc-300 font-sans">
                    "It works, just not the way we work. So the team invented five extra steps around it."
                  </p>
                  <div className="flex border-zinc-800/50 border-t mt-10 pt-6 gap-x-4 gap-y-4 items-center">
                    <div className="h-12 w-12 rounded-full bg-zinc-800 overflow-hidden flex-shrink-0 border border-zinc-700/50">
                      <img src="/recovered-assets/0dcdd895-28af-4d5d-87be-b6281ddcffd2_320w.png" alt="Steve Urbanski" className="opacity-80 w-full h-full object-cover grayscale" />
                    </div>
                    <div>
                      <h3 className="group-hover:text-zinc-300 transition-colors text-base font-normal text-white tracking-tight font-grotesk mb-1">Steve Urbanski</h3>
                      <p className="sm:text-sm uppercase text-xs font-normal text-zinc-500 tracking-widest font-pixel">Owner, Through the Leash</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="group h-full">
                <div className="sm:p-10 group-hover:border-zinc-700 transition-colors flex flex-col bg-zinc-900/60 h-full border-zinc-800/80 border rounded-2xl pt-8 pr-8 pb-8 pl-8 relative shadow-2xl backdrop-blur-md">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-10 h-10 text-zinc-700 mb-6">
                    <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
                    <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
                  </svg>
                  <p className="sm:text-2xl leading-relaxed flex-grow text-xl font-light text-zinc-300 font-sans">
                    "Only one person knows how it all works. When they are busy or away, everything slows down."
                  </p>
                  <div className="flex items-center gap-4 mt-10 pt-6 border-t border-zinc-800/50">
                    <div className="h-12 w-12 rounded-full bg-zinc-800 overflow-hidden flex-shrink-0 border border-zinc-700/50">
                      <img src="/recovered-assets/b1005be2-22ee-4d22-a288-9eafac19a3a7_320w.png" alt="Peter Straub" className="opacity-80 w-full h-full object-cover grayscale" />
                    </div>
                    <div>
                      <h3 className="group-hover:text-zinc-300 transition-colors text-base font-normal text-white tracking-tight font-grotesk mb-1">Peter Straub</h3>
                      <p className="sm:text-sm uppercase text-xs font-normal text-zinc-500 tracking-widest font-pixel">Franchise Partner, SprayNet</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="testimonial-sticky sticky top-40 z-30 w-full"></div>
        </div>
      </div>
    </section>
  );
}
