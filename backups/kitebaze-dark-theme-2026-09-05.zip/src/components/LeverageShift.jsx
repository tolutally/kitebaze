export default function LeverageShift() {
  return (
    <section className="sm:py-32 bg-black z-10 pt-24 pb-24 relative">
      <div className="sm:px-6 lg:px-8 max-w-7xl z-30 mr-auto ml-auto pr-4 pl-4 relative">
        <h2 className="leading-tight typography-reveal sm:text-5xl lg:text-6xl text-4xl font-normal text-white tracking-tight font-grotesk">
          <span className="overflow-hidden inline-block align-bottom pb-1 -mb-1">
            <span className="reveal-text inline-block font-medium text-[#FE4C00]">Your tools aren't always the problem. The gaps between them are.</span>
          </span>
          <br className="hidden sm:block" />
        </h2>
        <div className="sm:text-2xl leading-relaxed text-lg font-light text-zinc-300 font-sans max-w-7xl space-y-8">
          <p className="fade-up-element font-inter max-w-7xl mt-4">Most growing service businesses don't need another subscription. You already have a scheduling system, an inbox, forms, a calendar, spreadsheets and accounting.</p>
          <p className="fade-up-element font-inter max-w-7xl">The problem is that they don't talk to each other. So people become the integration: they copy, paste, chase, check, re-enter, forward and update.</p>
          <p className="fade-up-element font-normal text-[#FE4C00] tracking-tight font-inter">
            Every tool you add makes this worse, not better. The tenth system doesn't reduce the coordination work, it creates more of it.
          </p>
        </div>
      </div>
    </section>
  );
}
