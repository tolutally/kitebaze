import { useEffect, useState } from 'react';

export default function Hero() {
  const phrase = "what's missing";
  const [typedPhrase, setTypedPhrase] = useState('');

  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setTypedPhrase(phrase);
      return undefined;
    }

    let cancelled = false;
    let timer;
    const wait = (delay) => new Promise((resolve) => { timer = window.setTimeout(resolve, delay); });

    const animate = async () => {
      while (!cancelled) {
        for (let index = 1; index <= phrase.length && !cancelled; index += 1) {
          setTypedPhrase(phrase.slice(0, index));
          await wait(95);
        }
        await wait(1800);
        for (let index = phrase.length - 1; index >= 0 && !cancelled; index -= 1) {
          setTypedPhrase(phrase.slice(0, index));
          await wait(55);
        }
        await wait(500);
      }
    };

    animate();
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, []);

  return (
    <section className="overflow-hidden flex sm:pt-40 md:pt-48 md:pb-20 bg-zinc-950 border-zinc-900/50 border-b pt-32 pb-16 relative">
      <div className="sm:px-10 lg:px-16 z-10 w-full max-w-7xl mr-auto ml-auto px-6 relative">
        <div className="max-w-8xl text-center">
          <h1 className="leading-[1.05] sm:text-5xl md:text-6xl lg:text-8xl text-4xl font-medium text-white tracking-tight font-space-grotesk text-center mt-8">
            Keep what works. We
            <br />
            <span className="inline-block align-middle">connect&nbsp;</span>
            <span className="inline-flex min-w-[14.5ch] items-center justify-start mt-3 bg-[#FE4C00] px-5 sm:px-6 py-1 sm:py-0 whitespace-nowrap" aria-label={phrase}>
              <span aria-hidden="true">{typedPhrase}</span><span className="hero-typewriter-cursor" aria-hidden="true"></span>
            </span>
          </h1>
          <p className="leading-relaxed sm:text-xl text-base font-light text-zinc-300 font-inter text-center max-w-7xl mt-8 mb-10">
            Kitebaze connects the software you already pay for — scheduling, accounting, documents, email, spreadsheets —<br className="hidden sm:block" /> so nobody has to move do things manually anymore.
          </p>
          <a href="https://calendly.com/kindling-solutions/kindling-solutions" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center hover:bg-zinc-900 transition-colors sm:w-auto text-sm font-normal text-white font-inter bg-[#FE4C00] w-fit rounded-full pt-3.5 pr-8 pb-3.5 pl-8">Show Us Your Workflow</a>
        </div>
      </div>
    </section>
  );
}
