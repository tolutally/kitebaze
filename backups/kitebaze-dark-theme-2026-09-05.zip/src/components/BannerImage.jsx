export default function BannerImage() {
  return (
    <section className="sm:pb-12 z-40 bg-black border-zinc-900 border-t pt-24 pb-8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="fade-up-element rounded-2xl sm:rounded-3xl overflow-hidden border border-zinc-800/50">
          <img
            src="/recovered-assets/c18e3593-27b3-4df7-82f6-35fdb9b26ebb_1600w.png"
            alt="Ignite Whats Next Keyboard Keys Banner"
            className="w-full h-auto object-cover"
          />
        </div>
      </div>
    </section>
  );
}
