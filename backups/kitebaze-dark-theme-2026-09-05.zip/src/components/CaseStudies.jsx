import { Link } from 'react-router-dom';

export default function CaseStudies() {
  return (
      <div className="sm:px-6 lg:px-8 z-10 max-w-7xl mr-auto ml-auto pr-4 pl-4 relative">
        <div className="flex flex-col lg:flex-row gap-10 fade-up-element mb-0 gap-x-10 gap-y-10 items-start justify-between">
          <h2 className="text-4xl font-medium tracking-tight text-white max-w-3xl leading-tight font-grotesk sm:text-6xl">
            <span className="text-[#FE4C00]">What we build.</span> In the real world.
          </h2>
        </div>
        <div className="flex flex-col lg:flex-row gap-10 fade-up-element mb-16 gap-x-10 gap-y-10 items-start justify-between">
          <h2 className="leading-tight text-base sm:text-xl font-medium text-white tracking-tight font-grotesk max-w-3xl">
            Practical automation for the work between the work.
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 fade-up-element gap-x-4 gap-y-4">
          <Link to="/case-studies#xerox" className="flex flex-col hover:border-zinc-700 transition-colors bg-zinc-700/40 h-[280px] sm:h-[420px] border-zinc-800/50 border rounded-3xl pt-0 pr-8 pb-8 pl-8 backdrop-blur-md justify-between">
            <div className="flex pt-6 items-center justify-between">
              <div className="flex gap-3 items-center">
                <img src="/recovered-assets/f1effcd7-271a-45bb-bcb1-c46652da778c_320w.jpg" alt="User" className="w-10 h-10 rounded-full object-cover grayscale border border-zinc-700" />
                <div className="text-sm font-medium text-white leading-none font-grotesk">Xerox</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{ color: 'rgb(255, 255, 255)' }}>
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </div>
            <div>
              <h3 className="leading-tight text-xl font-medium text-white tracking-tight font-grotesk mb-20 pb-0">Enquiry → Booking</h3>
              <p className="text-zinc-400 leading-relaxed text-base font-light font-inter">Capture the request, ask for what's missing, route it and create the job record before anyone opens their laptop.</p>
            </div>
          </Link>
          <Link to="/case-studies#crow" className="flex flex-col hover:border-zinc-700 transition-colors bg-zinc-700/40 h-[280px] sm:h-[420px] border-zinc-800/50 border rounded-3xl pt-0 pr-8 pb-8 pl-8 backdrop-blur-md justify-between no-underline">
            <div className="flex pt-6 items-center justify-between">
              <div className="flex gap-3 items-center">
                <img src="/recovered-assets/7db84f60-1d18-48fb-9287-aa8597dbcb7b_320w.jpg" alt="User" className="w-10 h-10 rounded-full object-cover grayscale border border-zinc-700" />
                <div className="text-sm font-medium text-white leading-snug font-grotesk">Crow Estate<br />Planning &amp; Probate</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{ color: 'rgb(255, 255, 255)' }}>
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </div>
            <div>
              <h3 className="leading-tight text-xl font-medium text-white tracking-tight font-grotesk mb-8">Job → Invoice</h3>
              <p className="text-zinc-400 leading-relaxed text-base font-light font-inter">Work gets completed, documented, priced and billed without someone re-entering it in a second system.</p>
            </div>
          </Link>
          <Link to="/case-studies#squlpt" className="flex flex-col hover:border-zinc-700 transition-colors bg-zinc-700/40 h-[280px] sm:h-[420px] border-zinc-800/50 border rounded-3xl pt-0 pr-8 pb-8 pl-8 backdrop-blur-md justify-between no-underline">
            <div className="flex pt-6 items-center justify-between">
              <div className="flex gap-3 items-center">
                <img src="/recovered-assets/54571749-f1d2-4b32-9e2f-136640adae0d_320w.jpg" alt="User" className="w-10 h-10 rounded-full object-cover grayscale border border-zinc-700" />
                <div className="text-sm font-medium text-white leading-none font-grotesk">Squlpt Body</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{ color: 'rgb(255, 255, 255)' }}>
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </div>
            <div>
              <h3 className="leading-tight text-xl font-medium text-white tracking-tight font-grotesk mb-14">Follow up → Paid</h3>
              <p className="text-zinc-400 leading-relaxed text-base font-light font-inter">Quotes with no reply, documents that never came back, invoices past due. Followed up on schedule, not when someone remembers.</p>
            </div>
          </Link>
          <Link to="/case-studies#documents" className="flex flex-col hover:border-zinc-700 transition-colors bg-zinc-700/40 h-[280px] sm:h-[420px] border-zinc-800/50 border rounded-3xl pt-0 pr-8 pb-8 pl-8 backdrop-blur-md justify-between no-underline">
            <div className="flex pt-6 items-center justify-between">
              <div className="flex gap-3 items-center">
                <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ color: 'rgb(254, 76, 0)' }}>
                    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
                    <path d="M14 2v4a2 2 0 0 0 2 2h4"></path>
                    <path d="M10 9H8"></path>
                    <path d="M16 13H8"></path>
                    <path d="M16 17H8"></path>
                  </svg>
                </div>
                <div className="text-sm font-medium text-white leading-none font-grotesk">Any Business</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{ color: 'rgb(255, 255, 255)' }}>
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </div>
            <div>
              <h3 className="leading-tight text-xl font-medium text-white tracking-tight font-grotesk mb-14">Documents → Data</h3>
              <p className="text-zinc-400 leading-relaxed text-base font-light font-inter">Receipts, PDFs, forms and email threads read and routed into the systems that need them.</p>
            </div>
          </Link>
          <Link
            to="/case-studies"
            className="flex flex-col overflow-hidden group bg-center text-white bg-stone-950 h-[280px] sm:h-[420px] bg-[url('/recovered-assets/photo-1764946023990-2780e4905bb5.jpg')] bg-cover border-zinc-800/100 border rounded-3xl pt-8 pr-8 pb-8 pl-8 relative justify-between"
          >
            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors duration-500"></div>
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#FE4C00]/20 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2 group-hover:bg-[#FE4C00]/30 transition-colors duration-500"></div>
            <div className="flex text-white relative items-start justify-between">
              <span className="text-lg font-medium tracking-tight font-grotesk">Your Workflow</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px]" aria-hidden="true" style={{ color: 'rgb(255, 255, 255)' }}>
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </div>
            <div className="relative z-10 mt-auto mb-8">
              <p className="leading-relaxed text-base font-light text-white font-inter max-w-[260px] pb-12">Maybe your job software does 80% of what you need. That's exactly the kind of problem we want to see addressed.</p>
            </div>
            <div className="space-y-3 text-sm text-zinc-300 relative z-10 font-inter">
              <Link to="/case-studies" className="inline-flex items-center justify-center hover:bg-zinc-900 transition-colors sm:w-auto text-sm font-normal text-white font-inter bg-[#FE4C00] w-fit rounded-full pt-3.5 pr-8 pb-3.5 pl-8">Show Us the Mess</Link>
            </div>
          </Link>
        </div>
      </div>
  );
}
