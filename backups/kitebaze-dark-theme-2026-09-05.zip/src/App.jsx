import { Outlet } from 'react-router-dom';
import useScrollReveal from './hooks/useScrollReveal.js';
import BackgroundVideo from './components/BackgroundVideo.jsx';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import AboutPage from './pages/AboutPage.jsx';

export default function App() {
  useScrollReveal();

  if (window.location.pathname === '/about-us' || window.location.pathname === '/about') {
    return <AboutPage />;
  }

  return (
    <>
      <BackgroundVideo />
      <Header />
      <main className="flex-grow z-20 bg-black">
        <Outlet />
      </main>
      <Footer />
    </>
  );
}
