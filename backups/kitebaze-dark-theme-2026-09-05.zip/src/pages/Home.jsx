import Hero from '../components/Hero.jsx';
import VideoIntro from '../components/VideoIntro.jsx';
import ScaleBreak from '../components/ScaleBreak.jsx';
import StopStitching from '../components/StopStitching.jsx';
import Approach from '../components/Approach.jsx';
import StartHere from '../components/StartHere.jsx';
import Results from '../components/Results.jsx';
import LeverageShift from '../components/LeverageShift.jsx';
import LogoBanner from '../components/LogoBanner.jsx';
import CaseStudies from '../components/CaseStudies.jsx';
import WhyKitebaze from '../components/WhyKitebaze.jsx';
import Testimonials from '../components/Testimonials.jsx';
import CTA from '../components/CTA.jsx';
import BannerImage from '../components/BannerImage.jsx';
import FAQ from '../components/FAQ.jsx';
import MarqueeBanner from '../components/MarqueeBanner.jsx';

export default function Home() {
  return (
    <>
      <Hero />
      <VideoIntro />
      <ScaleBreak />
      <StopStitching />
      <Approach />
      <StartHere />
      <Results />
      <LeverageShift />
      <LogoBanner />
      <section className="bg-black border-zinc-900 border-t pt-24 pb-24 relative overflow-hidden z-10">
        <CaseStudies />
        <WhyKitebaze />
        <Testimonials />
        <CTA />
        <BannerImage />
        <FAQ />
        <MarqueeBanner />
      </section>
    </>
  );
}
