export default function AboutUs() {
  return (
    <section className="sm:pt-40 md:pt-48 pt-32 pb-24 relative min-h-[60vh]">
      <div className="sm:px-10 lg:px-16 z-10 w-full max-w-5xl mr-auto ml-auto px-6 relative text-center">
        <h1 className="leading-[1.05] sm:text-5xl md:text-6xl text-4xl font-medium text-white tracking-tight font-space-grotesk">
          About Us
        </h1>
        <p className="leading-relaxed sm:text-xl text-base font-light text-zinc-300 font-inter mt-8">
          Content coming soon.
        </p>
      </div>
    </section>
  );
}
