import { useState } from 'react';
import Header from '../components/Header.jsx';
import Footer from '../components/Footer.jsx';

const beliefs = [
  {
    title: 'Systems over hustle',
    bullets: [
      'Operators deserve to run a business with clarity and control—not constant context switching and late-night follow-ups.',
      "Most companies don't hit a strategy ceiling. They hit an operating ceiling.",
      "Moving tools around doesn't fix it. Systems have to run without manual enforcement.",
      "AI is the lever, but only when it's installed inside how you actually operate.",
    ],
  },
  {
    title: 'Operations before automation',
    bullets: [
      'Map the work before choosing the tools.',
      'Automation should remove friction, not hide a broken process.',
      'Every system has to hold up when the exceptions arrive.',
    ],
  },
  {
    title: 'AI as leverage',
    bullets: [
      'AI should live inside the way your business actually operates.',
      'The best systems make good execution repeatable without constant oversight.',
      'Technology creates leverage when people can trust it to do the work.',
    ],
  },
];

const people = [
  {
    name: 'Jason Katz',
    role: 'Co-Founder',
    image: '/about-assets/jason-katz.jpg',
    bio: 'Jason has built, led, and exited companies ranging from $50M to $2B and is currently scaling another to $200M+. Over 17 years, Jason has worked at the intersection of technology, strategy, and operations—building the systems behind growth, not just advising on it. Jason builds AI systems and the underlying operating infrastructure, with the work grounded in how businesses actually run—so implementation holds up outside a demo.',
  },
  {
    name: 'Leigh Buckley',
    role: 'Co-Founder',
    image: '/about-assets/leigh-buckley.jpg',
    bio: 'Leigh brings an operator’s eye to every engagement—turning complex processes into clear systems that teams can actually run. Her work connects strategy, people, and implementation so the new operating model lasts beyond launch.',
  },
];

export default function AboutPage() {
  const [belief, setBelief] = useState(0);
  const [person, setPerson] = useState(0);
  const active = people[person];

  const shiftBelief = (direction) => {
    setBelief((current) => (current + direction + beliefs.length) % beliefs.length);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main>
        <section className="about-hero relative min-h-[585px] flex items-center justify-center overflow-hidden border-b border-zinc-900">
          <img src="/about-assets/station-hero.jpg" alt="Grand Central station" className="absolute inset-0 h-full w-full object-cover grayscale" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/25 to-black/45"></div>
          <div className="relative z-10 max-w-5xl mx-auto px-6 pt-28 text-center">
            <h1 className="font-space-grotesk text-6xl sm:text-7xl lg:text-8xl font-medium tracking-tight">The Spark.</h1>
            <p className="max-w-4xl mx-auto mt-6 text-lg sm:text-2xl font-light leading-relaxed text-zinc-200">Before the build, there’s a spark: the moment you admit the current way won’t scale. Here’s what we’re doing about it—and who we are.</p>
            <a href="https://calendly.com/kindling-solutions/kindling-solutions" className="inline-flex mt-9 items-center justify-center rounded-full bg-[#FE4C00] px-8 py-3.5 text-sm font-medium hover:bg-[#e64500] transition-colors">Book a Call</a>
          </div>
        </section>

        <section className="flex min-h-[640px] items-start justify-center border-b border-zinc-900 px-6 py-24 sm:py-28">
          <div className="mx-auto max-w-[1420px] text-center">
            <h2 className="mx-auto font-space-grotesk text-[2.7rem] font-normal leading-[1.02] tracking-[-0.045em] sm:text-6xl lg:text-[5.35rem]">
              AI that holds up in the real<span className="hidden lg:inline"><br /></span><span className="lg:hidden"> </span>world. <span className="text-[#FE4C00]">Built by operators who<span className="hidden lg:inline"><br /></span><span className="lg:hidden"> </span>have been in your seat.</span>
            </h2>
            <p className="mx-auto mt-12 max-w-4xl font-light leading-[1.25] text-zinc-100 sm:text-2xl lg:text-[2rem]">We build AI-run operations for operators who want<br className="hidden sm:block" /> the next level without the chaos tax.</p>
          </div>
        </section>

        <section className="border-b border-zinc-900 px-5 py-20 sm:px-8 sm:py-28">
          <div className="mx-auto max-w-[1720px]">
            <h2 className="font-space-grotesk text-[3.25rem] font-normal leading-[1.03] tracking-[-0.045em] sm:text-7xl lg:text-[5.4rem]">
              Stop being the glue.<br /><span className="text-[#FE4C00]">Build the machine.</span>
            </h2>
            <p className="mt-10 max-w-[1160px] text-lg font-light leading-[1.65] text-zinc-400 sm:text-2xl lg:text-[1.75rem]">Kitebaze builds AI-powered operations that run underneath the business—so execution<br className="hidden xl:block" /> compounds, quality holds, and the business keeps moving when you’re not there to push it.</p>

            <div className="mt-24 overflow-hidden rounded-[2rem] border border-[#5c240c]/60 bg-[#0c0b0a] sm:mt-36">
              <div className="relative min-h-[485px] px-7 py-12 sm:px-14 sm:py-16">
                <div className="absolute right-7 top-12 flex items-center gap-2 sm:right-14 sm:top-16">
                  {beliefs.map((item, index) => (
                    <span key={item.title} className={`block h-2 rounded-full transition-all ${belief === index ? 'w-14 bg-[#FE4C00]' : 'w-3 bg-[#5a2a12]'}`}></span>
                  ))}
                </div>
                <p className="text-lg font-medium text-[#FE4C00] sm:text-xl">What we believe</p>
                <h3 className="mt-9 max-w-4xl font-space-grotesk text-4xl font-medium tracking-[-0.035em] sm:text-5xl">{beliefs[belief].title}</h3>
                <ul className="mt-9 max-w-[1450px] space-y-5 text-lg font-light leading-relaxed text-zinc-300 sm:text-2xl">
                  {beliefs[belief].bullets.map((bullet) => (
                    <li key={bullet} className="flex gap-5"><span className="mt-[0.65em] h-2.5 w-2.5 shrink-0 rounded-full bg-[#FE4C00]"></span><span>{bullet}</span></li>
                  ))}
                </ul>
              </div>
              <div className="flex items-center justify-between border-t border-[#3b1b0d] px-7 py-8 sm:px-14 sm:py-9">
                <div className="flex gap-3">
                  <button onClick={() => shiftBelief(-1)} aria-label="Previous belief" className="flex h-16 w-16 items-center justify-center rounded-2xl border border-[#5c240c] bg-[#2a1208] text-2xl text-zinc-300 transition-colors hover:border-[#FE4C00] sm:h-20 sm:w-20">←</button>
                  <button onClick={() => shiftBelief(1)} aria-label="Next belief" className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#FE4C00] text-2xl text-white transition-colors hover:bg-[#e64500] sm:h-20 sm:w-20">→</button>
                </div>
                <span className="text-lg text-zinc-400 sm:text-xl">{belief + 1}/{beliefs.length}</span>
              </div>
            </div>
          </div>
        </section>

        <section className="px-6 py-28 sm:py-36 bg-zinc-950 border-b border-zinc-900">
          <div className="max-w-7xl mx-auto">
            <h2 className="font-space-grotesk text-5xl sm:text-7xl font-medium tracking-tight">Built by Operators.</h2>
            <p className="mt-5 max-w-3xl text-lg sm:text-2xl font-light text-zinc-400">Led by the people who’ve scaled businesses—and can actually install what they recommend.</p>
            <div className="mt-16 grid sm:grid-cols-2 gap-6">
              {people.map((item, index) => (
                <button key={item.name} onClick={() => setPerson(index)} className={`group relative min-h-[540px] overflow-hidden rounded-3xl border text-left ${person === index ? 'border-[#FE4C00]' : 'border-zinc-800'} transition-colors`}>
                  <img src={item.image} alt={item.name} className="absolute inset-0 w-full h-full object-cover grayscale transition-transform duration-700 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent"></div>
                  <div className="absolute inset-x-0 bottom-0 p-8 sm:p-10"><h3 className="font-space-grotesk text-3xl font-medium">{item.name}</h3><p className="mt-1 text-zinc-400">{item.role}</p></div>
                </button>
              ))}
            </div>
            <div className="mt-10 grid lg:grid-cols-[.65fr_1.35fr] gap-8 lg:gap-16 rounded-3xl border border-zinc-800 bg-black p-8 sm:p-12">
              <div><h3 className="font-space-grotesk text-4xl font-medium text-[#FE4C00]">{active.name}</h3><p className="mt-2 text-zinc-400">{active.role}</p></div>
              <p className="text-lg sm:text-xl font-light leading-relaxed text-zinc-300">{active.bio}</p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
