import { useEffect, useLayoutEffect } from "react";

const sourceScripts = [
  {
    "src": "https://cdn.tailwindcss.com",
    "type": "",
    "id": "",
    "async": false,
    "defer": false,
    "content": ""
  },
  {
    "src": "",
    "type": "",
    "id": "",
    "async": false,
    "defer": false,
    "content": "\n    history.scrollRestoration = 'manual';\n  "
  },
  {
    "src": "",
    "type": "",
    "id": "",
    "async": false,
    "defer": false,
    "content": "\n    (function () {\n        const toggle = document.getElementById(\"solutions-toggle\");\n        const menu = document.getElementById(\"solutions-menu\");\n        const arrow = document.getElementById(\"solutions-arrow\");\n        if (!toggle || !menu || !arrow) return;\n        toggle.addEventListener(\"click\", function (event) {\n          event.stopPropagation();\n          menu.classList.toggle(\"hidden\");\n          arrow.classList.toggle(\"rotate-180\");\n        });\n        document.addEventListener(\"click\", function () {\n          menu.classList.add(\"hidden\");\n          arrow.classList.remove(\"rotate-180\");\n        });\n        menu.addEventListener(\"click\", function (event) { event.stopPropagation(); });\n      })();\n      (function () {\n        const mobileToggle = document.getElementById(\"mobile-menu-toggle\");\n        const mobileMenu = document.getElementById(\"mobile-menu\");\n        const ham1 = document.getElementById(\"ham-1\");\n        const ham2 = document.getElementById(\"ham-2\");\n        const ham3 = document.getElementById(\"ham-3\");\n        if (!mobileToggle || !mobileMenu) return;\n        mobileToggle.addEventListener(\"click\", function () {\n          const open = !mobileMenu.classList.contains(\"hidden\");\n          mobileMenu.classList.toggle(\"hidden\");\n          if (!open) {\n            ham1.style.transform = \"translateY(8px) rotate(45deg)\";\n            ham2.style.opacity = \"0\";\n            ham3.style.transform = \"translateY(-8px) rotate(-45deg)\";\n          } else {\n            ham1.style.transform = \"\";\n            ham2.style.opacity = \"\";\n            ham3.style.transform = \"\";\n          }\n        });\n      })();\n      (function () {\n        const toggle = document.getElementById(\"mobile-solutions-toggle\");\n        const menu = document.getElementById(\"mobile-solutions-menu\");\n        const arrow = document.getElementById(\"mobile-solutions-arrow\");\n        if (!toggle || !menu || !arrow) return;\n        toggle.addEventListener(\"click\", function () {\n          menu.classList.toggle(\"hidden\");\n          menu.classList.toggle(\"flex\");\n          arrow.classList.toggle(\"rotate-180\");\n        });\n      })();\n  "
  },
  {
    "src": "",
    "type": "",
    "id": "",
    "async": false,
    "defer": false,
    "content": "\n      document.addEventListener(\"DOMContentLoaded\", function () {\n          const section = document.querySelector(\".scale-break-section\");\n          if (!section) return;\n          const observer = new IntersectionObserver(function (entries) {\n            entries.forEach(function (entry) {\n              if (entry.isIntersecting) {\n                setTimeout(() => { section.classList.add(\"animate-now\"); }, 800);\n                observer.unobserve(section);\n              }\n            });\n          }, { threshold: 0.35 });\n          observer.observe(section);\n        });\n    "
  },
  {
    "src": "",
    "type": "",
    "id": "",
    "async": false,
    "defer": false,
    "content": "\n      (function () {\n      function initApproach() {\n        const steps = document.querySelectorAll(\".approach-step\");\n        if (!steps.length) return;\n        const title = document.getElementById(\"approach-title\");\n        const copy = document.getElementById(\"approach-copy\");\n        const progress = document.querySelector(\".approach-progress\");\n        const dot = document.querySelector(\".approach-dot\");\n        const states = [\n          { offset: 986, rotation: 0 },\n          { offset: 498, rotation: 120 },\n          { offset: 0, rotation: 240 },\n        ];\n        function setStep(index) {\n          steps.forEach(s => s.classList.remove(\"active\"));\n          steps[index].classList.add(\"active\");\n          title.textContent = steps[index].dataset.title;\n          copy.textContent = steps[index].dataset.copy;\n          progress.style.strokeDashoffset = states[index].offset;\n          dot.style.transform = `rotate(${states[index].rotation}deg)`;\n        }\n        steps.forEach((step, i) => {\n          step.addEventListener(\"mouseenter\", () => setStep(i));\n          step.addEventListener(\"click\", () => setStep(i));\n          step.addEventListener(\"touchstart\", () => setStep(i), { passive: true });\n        });\n        setStep(0);\n      }\n      if (document.readyState === \"loading\") {\n        document.addEventListener(\"DOMContentLoaded\", initApproach);\n      } else {\n        initApproach();\n      }\n    })();\n    "
  },
  {
    "src": "",
    "type": "",
    "id": "",
    "async": false,
    "defer": false,
    "content": "\n    window.scrollTo(0, 0);\n  \n      document.addEventListener(\"DOMContentLoaded\", () => {\n        // Strip pre-applied is-visible so observer controls all animations\n        document.querySelectorAll('.fade-up-element, .typography-reveal').forEach(el => {\n          el.classList.remove('is-visible');\n        });\n  \n        const observerOptions = { root: null, rootMargin: \"0px\", threshold: 0.15 };\n        const observer = new IntersectionObserver((entries, observer) => {\n          entries.forEach(entry => {\n            if (entry.isIntersecting) { entry.target.classList.add('is-visible'); }\n          });\n        }, observerOptions);\n        document.querySelectorAll('.typography-reveal, .fade-up-element').forEach((el) => { observer.observe(el); });\n  \n        const testimonials = document.querySelectorAll('.testimonial-sticky');\n        window.addEventListener('scroll', () => {\n          testimonials.forEach((el, index) => {\n            const rect = el.getBoundingClientRect();\n            const inner = el.querySelector('.testimonial-inner');\n            if (!inner) return;\n            const offsetTop = parseInt(window.getComputedStyle(el).top, 10);\n            if (rect.top <= offsetTop && index < testimonials.length - 1) {\n              const nextEl = testimonials[index + 1];\n              const nextRect = nextEl.getBoundingClientRect();\n              const distance = nextRect.top - rect.top;\n              const threshold = 180;\n              if (distance < threshold) {\n                const progress = 1 - (distance / threshold);\n                inner.style.transform = `scale(${1 - (progress * 0.05)})`;\n                inner.style.filter = `brightness(${1 - (progress * 0.5)})`;\n              } else {\n                inner.style.transform = 'scale(1)';\n                inner.style.filter = 'brightness(1)';\n              }\n            } else {\n              inner.style.transform = 'scale(1)';\n              inner.style.filter = 'brightness(1)';\n            }\n          });\n        });\n      });\n  "
  }
];
const sourceHtmlId = "";
const sourceHtmlClassName = "";
const sourceHtmlStyle = "";
const sourceBodyId = "";
const sourceBodyClassName = "antialiased selection:bg-zinc-800 selection:text-white flex flex-col min-h-screen text-white font-sans bg-black";
const sourceBodyStyle = "";
const inlineEventAttributeNames = [
  "click",
  "change",
  "input",
  "submit",
  "mouseover",
  "mouseout",
  "mouseenter",
  "mouseleave",
  "keydown",
  "keyup",
  "focus",
  "blur"
];

function applyElementAttributes(element, attributes) {
  const previousId = element.id;
  const previousClassName = element.className;
  const previousStyleAttribute = element.getAttribute("style");

  if (attributes.id) {
    element.id = attributes.id;
  }
  attributes.className
    .split(/\s+/)
    .filter(Boolean)
    .forEach((className) => element.classList.add(className));
  if (attributes.style) {
    element.style.cssText = [element.style.cssText, attributes.style]
      .filter(Boolean)
      .join("; ");
  }

  return () => {
    element.id = previousId;
    element.className = previousClassName;
    if (previousStyleAttribute === null) {
      element.removeAttribute("style");
    } else {
      element.setAttribute("style", previousStyleAttribute);
    }
  };
}

function applySourceRootAttributes() {
  const restoreHtml = applyElementAttributes(document.documentElement, {
    id: sourceHtmlId,
    className: sourceHtmlClassName,
    style: sourceHtmlStyle,
  });
  const restoreBody = applyElementAttributes(document.body, {
    id: sourceBodyId,
    className: sourceBodyClassName,
    style: sourceBodyStyle,
  });

  return () => {
    restoreBody();
    restoreHtml();
  };
}

function attachInlineEventHandlers(root) {
  const cleanups = [];

  inlineEventAttributeNames.forEach((eventName) => {
    root
      .querySelectorAll(`[data-aura-on${eventName}]`)
      .forEach((element) => {
        const handlerCode = element.getAttribute(`data-aura-on${eventName}`);
        if (!handlerCode) return;

        const listener = function (event) {
          const result = Function("event", handlerCode).call(element, event);
          if (result === false) {
            event.preventDefault();
            event.stopPropagation();
          }
        };
        element.addEventListener(eventName, listener);
        cleanups.push(() => element.removeEventListener(eventName, listener));
      });
  });

  return () => cleanups.forEach((cleanup) => cleanup());
}

function appendSourceScript(scriptInfo) {
  const script = document.createElement("script");
  if (scriptInfo.id) script.id = scriptInfo.id;
  if (scriptInfo.type) script.type = scriptInfo.type;
  if (scriptInfo.async) script.async = true;
  if (scriptInfo.defer) script.defer = true;
  if (scriptInfo.src) {
    script.src = scriptInfo.src;
  } else if (scriptInfo.content) {
    script.textContent = scriptInfo.content;
  }
  document.body.appendChild(script);
  return script;
}

export default function App() {
  useLayoutEffect(() => applySourceRootAttributes(), []);

  useEffect(() => {
    const detachInlineEventHandlers = attachInlineEventHandlers(document);
    const appendedScripts = sourceScripts
      .filter((scriptInfo) => scriptInfo.src || scriptInfo.content)
      .map(appendSourceScript);

    return () => {
      detachInlineEventHandlers();
      appendedScripts.forEach((script) => script.remove());
    };
  }, []);

  return (
    <div className="aura-source-body antialiased selection:bg-zinc-800 selection:text-white flex flex-col min-h-screen text-white font-sans bg-black">
      <div className="video-background-container fixed top-0 w-full h-screen -z-10" data-alpha-mask="80" style={{"maskImage": "linear-gradient(to bottom, transparent, black 0%, black 80%, transparent)", "WebkitMaskImage": "linear-gradient(to bottom, transparent, black 0%, black 80%, transparent)"}}>
          <video src="https://www.dropbox.com/scl/fi/2bcesx0wtw73f7czy93gv/freepik_everyone-in-the-photo-is-_2792017953.mp4?rlkey=q2h7ac32rl0khobmyrjfhxxmv&amp;st=yzkfu6yx&amp;dl=0" autoPlay="" loop="" muted="" playsInline="" className="w-full h-full object-cover"></video>
        </div>


        <header className="fixed top-0 left-0 right-0 z-50 border-b border-zinc-900/50 bg-black/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-32 items-center justify-between">
            <a href="/home" className="flex-shrink-0">
              <svg width="180" height="72" viewBox="0 0 2183 865" fill="none" xmlns="http://www.w3.org/2000/svg" className="">
                <g clipPath="url(#clip0_630_33)" className="">
                  <path d="M289.473 224.898H461.719C465.73 224.898 468.996 228.154 468.996 232.153V388.959C468.996 395.471 476.847 398.67 481.488 394.1L653.734 222.385C658.319 217.815 666.226 221.071 666.226 227.526V416.836C666.226 420.834 662.96 424.091 658.949 424.091H472.091C470.142 424.091 468.251 423.291 466.876 421.92L284.258 237.294C279.731 232.667 282.998 224.898 289.473 224.898Z" fill="#FE4C00" className=""></path>
                  <path d="M648.753 634.575H476.507C472.496 634.575 469.23 631.319 469.23 627.32V470.514C469.23 464.002 461.38 460.803 456.738 465.373L284.492 637.089C279.85 641.716 272 638.46 272 631.947V442.638C272 438.639 275.266 435.383 279.277 435.383H466.135C468.084 435.383 469.975 436.183 471.35 437.554L653.968 622.236C658.495 626.863 655.228 634.632 648.753 634.632V634.575Z" fill="#FE4C00"></path>
                </g>
                <path d="M776.214 419V224.973H817.237V310.523H819.795L889.618 224.973H938.788L866.786 311.849L939.64 419H890.565L837.416 339.229L817.237 363.861V419H776.214ZM955.173 419V273.48H995.532V419H955.173ZM975.447 254.721C969.447 254.721 964.3 252.732 960.005 248.753C955.773 244.71 953.657 239.879 953.657 234.257C953.657 228.699 955.773 223.931 960.005 219.952C964.3 215.909 969.447 213.888 975.447 213.888C981.447 213.888 986.563 215.909 990.795 219.952C995.09 223.931 997.237 228.699 997.237 234.257C997.237 239.879 995.09 244.71 990.795 248.753C986.563 252.732 981.447 254.721 975.447 254.721ZM1054.88 334.871V419H1014.52V273.48H1052.99V299.154H1054.69C1057.91 290.691 1063.31 283.996 1070.89 279.069C1078.47 274.08 1087.66 271.585 1098.46 271.585C1108.57 271.585 1117.38 273.795 1124.89 278.217C1132.41 282.638 1138.25 288.954 1142.42 297.165C1146.59 305.312 1148.67 315.039 1148.67 326.344V419H1108.32V333.545C1108.38 324.639 1106.1 317.692 1101.49 312.702C1096.88 307.649 1090.54 305.123 1082.45 305.123C1077.02 305.123 1072.22 306.291 1068.05 308.628C1063.95 310.965 1060.72 314.376 1058.39 318.86C1056.11 323.281 1054.95 328.618 1054.88 334.871ZM1220.77 421.368C1209.71 421.368 1199.7 418.526 1190.73 412.842C1181.83 407.094 1174.75 398.663 1169.51 387.546C1164.33 376.367 1161.74 362.661 1161.74 346.429C1161.74 329.755 1164.43 315.892 1169.8 304.839C1175.17 293.722 1182.3 285.417 1191.21 279.922C1200.18 274.364 1210 271.585 1220.67 271.585C1228.82 271.585 1235.61 272.974 1241.04 275.753C1246.54 278.469 1250.96 281.88 1254.3 285.985C1257.72 290.028 1260.3 294.007 1262.07 297.923H1263.3V224.973H1303.57V419H1263.78V395.694H1262.07C1260.18 399.736 1257.49 403.747 1254.02 407.726C1250.61 411.642 1246.16 414.895 1240.66 417.484C1235.23 420.074 1228.6 421.368 1220.77 421.368ZM1233.56 389.252C1240.06 389.252 1245.56 387.483 1250.04 383.946C1254.59 380.346 1258.06 375.325 1260.46 368.883C1262.93 362.44 1264.16 354.893 1264.16 346.24C1264.16 337.587 1262.96 330.071 1260.56 323.692C1258.16 317.313 1254.68 312.386 1250.14 308.912C1245.59 305.439 1240.06 303.702 1233.56 303.702C1226.92 303.702 1221.33 305.502 1216.79 309.102C1212.24 312.702 1208.8 317.692 1206.46 324.071C1204.12 330.45 1202.96 337.84 1202.96 346.24C1202.96 354.703 1204.12 362.188 1206.46 368.693C1208.86 375.135 1212.3 380.188 1216.79 383.852C1221.33 387.452 1226.92 389.252 1233.56 389.252ZM1363.77 224.973V419H1323.41V224.973H1363.77ZM1382.76 419V273.48H1423.12V419H1382.76ZM1403.04 254.721C1397.04 254.721 1391.89 252.732 1387.59 248.753C1383.36 244.71 1381.25 239.879 1381.25 234.257C1381.25 228.699 1383.36 223.931 1387.59 219.952C1391.89 215.909 1397.04 213.888 1403.04 213.888C1409.04 213.888 1414.15 215.909 1418.38 219.952C1422.68 223.931 1424.83 228.699 1424.83 234.257C1424.83 239.879 1422.68 244.71 1418.38 248.753C1414.15 252.732 1409.04 254.721 1403.04 254.721ZM1482.47 334.871V419H1442.11V273.48H1480.58V299.154H1482.28C1485.5 290.691 1490.9 283.996 1498.48 279.069C1506.06 274.08 1515.25 271.585 1526.05 271.585C1536.16 271.585 1544.97 273.795 1552.48 278.217C1560 282.638 1565.84 288.954 1570.01 297.165C1574.18 305.312 1576.26 315.039 1576.26 326.344V419H1535.9V333.545C1535.97 324.639 1533.69 317.692 1529.08 312.702C1524.47 307.649 1518.12 305.123 1510.04 305.123C1504.61 305.123 1499.81 306.291 1495.64 308.628C1491.53 310.965 1488.31 314.376 1485.98 318.86C1483.7 323.281 1482.53 328.618 1482.47 334.871ZM1660.29 476.602C1647.22 476.602 1636.01 474.802 1626.66 471.202C1617.38 467.665 1609.99 462.833 1604.49 456.706C1599 450.58 1595.43 443.696 1593.79 436.053L1631.11 431.032C1632.25 433.937 1634.05 436.653 1636.51 439.18C1638.98 441.706 1642.23 443.727 1646.27 445.243C1650.38 446.822 1655.37 447.611 1661.24 447.611C1670.02 447.611 1677.25 445.464 1682.94 441.169C1688.68 436.937 1691.56 429.832 1691.56 419.853V393.231H1689.85C1688.08 397.273 1685.43 401.094 1681.89 404.694C1678.36 408.294 1673.81 411.231 1668.25 413.505C1662.69 415.779 1656.06 416.916 1648.36 416.916C1637.43 416.916 1627.48 414.389 1618.51 409.337C1609.61 404.221 1602.5 396.42 1597.2 385.936C1591.95 375.388 1589.33 362.061 1589.33 345.956C1589.33 329.471 1592.02 315.702 1597.39 304.649C1602.75 293.596 1609.89 285.322 1618.8 279.827C1627.77 274.332 1637.59 271.585 1648.26 271.585C1656.41 271.585 1663.23 272.974 1668.72 275.753C1674.22 278.469 1678.64 281.88 1681.99 285.985C1685.4 290.028 1688.02 294.007 1689.85 297.923H1691.37V273.48H1731.44V420.421C1731.44 432.8 1728.41 443.159 1722.35 451.496C1716.28 459.833 1707.88 466.086 1697.15 470.254C1686.47 474.486 1674.19 476.602 1660.29 476.602ZM1661.15 386.599C1667.65 386.599 1673.15 384.988 1677.63 381.767C1682.18 378.483 1685.65 373.809 1688.05 367.746C1690.51 361.619 1691.75 354.293 1691.75 345.766C1691.75 337.24 1690.55 329.85 1688.15 323.597C1685.75 317.281 1682.27 312.386 1677.72 308.912C1673.18 305.439 1667.65 303.702 1661.15 303.702C1654.51 303.702 1648.92 305.502 1644.38 309.102C1639.83 312.639 1636.39 317.565 1634.05 323.881C1631.71 330.197 1630.54 337.492 1630.54 345.766C1630.54 354.166 1631.71 361.43 1634.05 367.556C1636.45 373.62 1639.89 378.325 1644.38 381.673C1648.92 384.957 1654.51 386.599 1661.15 386.599ZM881.47 502.775C880.712 495.132 877.46 489.195 871.712 484.964C865.964 480.732 858.164 478.616 848.311 478.616C841.616 478.616 835.963 479.563 831.353 481.458C826.742 483.29 823.205 485.848 820.742 489.132C818.342 492.416 817.142 496.143 817.142 500.311C817.016 503.785 817.742 506.817 819.321 509.406C820.963 511.996 823.205 514.238 826.047 516.133C828.89 517.965 832.174 519.575 835.9 520.965C839.627 522.291 843.606 523.428 847.838 524.375L865.27 528.544C873.733 530.439 881.502 532.965 888.576 536.123C895.65 539.281 901.776 543.165 906.955 547.776C912.134 552.387 916.145 557.818 918.987 564.071C921.892 570.324 923.377 577.493 923.44 585.577C923.377 597.451 920.345 607.746 914.345 616.462C908.408 625.115 899.818 631.842 888.576 636.642C877.396 641.379 863.912 643.747 848.122 643.747C832.458 643.747 818.816 641.347 807.194 636.547C795.636 631.747 786.604 624.642 780.099 615.231C773.656 605.757 770.277 594.041 769.961 580.082H809.657C810.1 586.588 811.963 592.02 815.247 596.378C818.595 600.672 823.047 603.925 828.605 606.136C834.227 608.283 840.574 609.357 847.648 609.357C854.596 609.357 860.627 608.346 865.743 606.325C870.922 604.304 874.933 601.494 877.775 597.893C880.618 594.293 882.039 590.156 882.039 585.482C882.039 581.124 880.744 577.461 878.154 574.493C875.628 571.524 871.901 568.998 866.975 566.913C862.112 564.829 856.143 562.934 849.069 561.229L827.942 555.924C811.584 551.945 798.668 545.723 789.194 537.26C779.72 528.797 775.014 517.396 775.077 503.059C775.014 491.311 778.141 481.048 784.457 472.268C790.836 463.489 799.583 456.636 810.7 451.71C821.816 446.783 834.448 444.32 848.595 444.32C862.996 444.32 875.565 446.783 886.302 451.71C897.102 456.636 905.503 463.489 911.503 472.268C917.503 481.048 920.598 491.216 920.787 502.775H881.47ZM1002.68 643.842C987.969 643.842 975.242 640.716 964.505 634.463C953.831 628.147 945.588 619.368 939.778 608.125C933.967 596.82 931.062 583.714 931.062 568.808C931.062 553.776 933.967 540.639 939.778 529.397C945.588 518.091 953.831 509.312 964.505 503.059C975.242 496.743 987.969 493.585 1002.68 493.585C1017.4 493.585 1030.1 496.743 1040.77 503.059C1051.51 509.312 1059.78 518.091 1065.59 529.397C1071.4 540.639 1074.31 553.776 1074.31 568.808C1074.31 583.714 1071.4 596.82 1065.59 608.125C1059.78 619.368 1051.51 628.147 1040.77 634.463C1030.1 640.716 1017.4 643.842 1002.68 643.842ZM1002.87 612.578C1009.57 612.578 1015.16 610.683 1019.64 606.894C1024.13 603.041 1027.51 597.799 1029.78 591.167C1032.12 584.535 1033.29 576.987 1033.29 568.524C1033.29 560.061 1032.12 552.513 1029.78 545.881C1027.51 539.249 1024.13 534.007 1019.64 530.154C1015.16 526.302 1009.57 524.375 1002.87 524.375C996.116 524.375 990.432 526.302 985.821 530.154C981.274 534.007 977.832 539.249 975.495 545.881C973.221 552.513 972.084 560.061 972.084 568.524C972.084 576.987 973.221 584.535 975.495 591.167C977.832 597.799 981.274 603.041 985.821 606.894C990.432 610.683 996.116 612.578 1002.87 612.578ZM1127.57 446.973V641H1087.21V446.973H1127.57ZM1239.88 579.04V495.48H1280.24V641H1241.49V614.568H1239.97C1236.69 623.094 1231.23 629.947 1223.58 635.126C1216.01 640.305 1206.75 642.895 1195.83 642.895C1186.1 642.895 1177.54 640.684 1170.15 636.263C1162.76 631.842 1156.98 625.557 1152.81 617.41C1148.71 609.262 1146.62 599.504 1146.56 588.135V495.48H1186.92V580.935C1186.98 589.525 1189.29 596.314 1193.84 601.304C1198.38 606.294 1204.48 608.788 1212.12 608.788C1216.98 608.788 1221.53 607.683 1225.76 605.473C1230 603.199 1233.41 599.851 1236 595.43C1238.65 591.009 1239.94 585.546 1239.88 579.04ZM1387.26 495.48V525.796H1299.62V495.48H1387.26ZM1319.52 460.615H1359.88V596.283C1359.88 600.009 1360.45 602.915 1361.58 604.999C1362.72 607.02 1364.3 608.441 1366.32 609.262C1368.4 610.083 1370.8 610.494 1373.52 610.494C1375.41 610.494 1377.31 610.336 1379.2 610.02C1381.1 609.641 1382.55 609.357 1383.56 609.167L1389.91 639.2C1387.89 639.832 1385.05 640.558 1381.38 641.379C1377.72 642.263 1373.27 642.8 1368.02 642.99C1358.3 643.368 1349.77 642.074 1342.44 639.105C1335.18 636.137 1329.53 631.526 1325.49 625.273C1321.44 619.02 1319.45 611.125 1319.52 601.588V460.615ZM1408.21 641V495.48H1448.57V641H1408.21ZM1428.49 476.721C1422.49 476.721 1417.34 474.732 1413.04 470.753C1408.81 466.71 1406.7 461.879 1406.7 456.257C1406.7 450.699 1408.81 445.931 1413.04 441.952C1417.34 437.909 1422.49 435.888 1428.49 435.888C1434.49 435.888 1439.6 437.909 1443.83 441.952C1448.13 445.931 1450.28 450.699 1450.28 456.257C1450.28 461.879 1448.13 466.71 1443.83 470.753C1439.6 474.732 1434.49 476.721 1428.49 476.721ZM1533.31 643.842C1518.59 643.842 1505.87 640.716 1495.13 634.463C1484.46 628.147 1476.21 619.368 1470.4 608.125C1464.59 596.82 1461.69 583.714 1461.69 568.808C1461.69 553.776 1464.59 540.639 1470.4 529.397C1476.21 518.091 1484.46 509.312 1495.13 503.059C1505.87 496.743 1518.59 493.585 1533.31 493.585C1548.03 493.585 1560.72 496.743 1571.4 503.059C1582.13 509.312 1590.41 518.091 1596.22 529.397C1602.03 540.639 1604.93 553.776 1604.93 568.808C1604.93 583.714 1602.03 596.82 1596.22 608.125C1590.41 619.368 1582.13 628.147 1571.4 634.463C1560.72 640.716 1548.03 643.842 1533.31 643.842ZM1533.5 612.578C1540.19 612.578 1545.78 610.683 1550.27 606.894C1554.75 603.041 1558.13 597.799 1560.41 591.167C1562.74 584.535 1563.91 576.987 1563.91 568.524C1563.91 560.061 1562.74 552.513 1560.41 545.881C1558.13 539.249 1554.75 534.007 1550.27 530.154C1545.78 526.302 1540.19 524.375 1533.5 524.375C1526.74 524.375 1521.06 526.302 1516.45 530.154C1511.9 534.007 1508.46 539.249 1506.12 545.881C1503.85 552.513 1502.71 560.061 1502.71 568.524C1502.71 576.987 1503.85 584.535 1506.12 591.167C1508.46 597.799 1511.9 603.041 1516.45 606.894C1521.06 610.683 1526.74 612.578 1533.5 612.578ZM1658.2 556.871V641H1617.84V495.48H1656.3V521.154H1658.01C1661.23 512.691 1666.63 505.996 1674.21 501.069C1681.79 496.08 1690.98 493.585 1701.78 493.585C1711.88 493.585 1720.69 495.795 1728.21 500.217C1735.72 504.638 1741.57 510.954 1745.74 519.165C1749.9 527.312 1751.99 537.039 1751.99 548.344V641H1711.63V555.545C1711.69 546.639 1709.42 539.692 1704.81 534.702C1700.2 529.649 1693.85 527.123 1685.77 527.123C1680.33 527.123 1675.53 528.291 1671.37 530.628C1667.26 532.965 1664.04 536.376 1661.7 540.86C1659.43 545.281 1658.26 550.618 1658.2 556.871ZM1891.54 536.976L1854.59 539.249C1853.96 536.091 1852.6 533.249 1850.51 530.723C1848.43 528.133 1845.68 526.081 1842.27 524.565C1838.92 522.986 1834.91 522.196 1830.24 522.196C1823.99 522.196 1818.71 523.523 1814.42 526.175C1810.12 528.765 1807.98 532.239 1807.98 536.597C1807.98 540.071 1809.36 543.007 1812.14 545.408C1814.92 547.808 1819.69 549.734 1826.45 551.187L1852.79 556.492C1866.93 559.397 1877.48 564.071 1884.43 570.514C1891.38 576.956 1894.85 585.419 1894.85 595.904C1894.85 605.441 1892.04 613.81 1886.42 621.01C1880.86 628.21 1873.22 633.831 1863.49 637.874C1853.83 641.853 1842.68 643.842 1830.05 643.842C1810.79 643.842 1795.44 639.832 1784.01 631.81C1772.64 623.726 1765.97 612.736 1764.02 598.841L1803.71 596.757C1804.91 602.63 1807.82 607.115 1812.43 610.21C1817.04 613.241 1822.94 614.757 1830.14 614.757C1837.22 614.757 1842.9 613.399 1847.2 610.683C1851.56 607.904 1853.77 604.336 1853.83 599.978C1853.77 596.314 1852.22 593.314 1849.19 590.977C1846.16 588.577 1841.48 586.746 1835.17 585.482L1809.96 580.461C1795.75 577.619 1785.17 572.693 1778.23 565.682C1771.34 558.671 1767.9 549.734 1767.9 538.871C1767.9 529.523 1770.43 521.47 1775.48 514.712C1780.6 507.954 1787.76 502.743 1796.99 499.08C1806.27 495.417 1817.13 493.585 1829.58 493.585C1847.96 493.585 1862.42 497.469 1872.97 505.238C1883.58 513.007 1889.77 523.586 1891.54 536.976Z" fill="white" className=""></path>
                <defs>
                  <clipPath id="clip0_630_33">
                    <rect width="394.23" height="419.064" fill="white" transform="translate(272 220.195)"></rect>
                  </clipPath>
                </defs>
              </svg>
            </a>
            <div className="flex items-center gap-8">
              <nav className="hidden md:flex font-inter gap-x-8 items-center">
                <div className="relative">
                  <button type="button" id="solutions-toggle" className="flex items-center gap-2 hover:text-white transition-colors text-base font-normal text-zinc-400">
                      Solutions
                      <svg id="solutions-arrow" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="transition-transform duration-200">
                        <path d="m6 9 6 6 6-6"></path>
                      </svg>
                    </button>
                  <div id="solutions-menu" className="hidden absolute left-0 top-full mt-4 w-60 rounded-2xl border border-white/10 bg-black/60 backdrop-blur-xl shadow-2xl shadow-black/40 overflow-hidden z-50">
                    <a href="/fullstak" className="block px-5 py-4 text-sm text-zinc-300 hover:text-white hover:bg-white/10 transition-colors">FullStak</a>
                    <a href="/in-house-agent" className="block px-5 py-4 text-sm text-zinc-300 hover:text-white hover:bg-white/10 transition-colors border-t border-white/10">In-House
                      Agent</a>
                  </div>
                </div>
                <a href="/about-us" className="hover:text-white transition-colors text-base font-normal text-zinc-400">About
                  Us</a>
                <a href="/case-studies" className="hover:text-white transition-colors text-base font-normal text-zinc-400">Case
                  Studies</a>
              </nav>
              <a href="/contact-form" className="hidden md:inline-flex items-center justify-center hover:bg-zinc-900 transition-colors sm:w-auto text-sm font-normal text-white font-inter bg-[#FE4C00] rounded-full pt-3.5 pr-8 pb-3.5 pl-8">
                Get in Touch
              </a>
              <button type="button" id="mobile-menu-toggle" className="md:hidden flex flex-col gap-1.5 p-2" aria-label="Open menu">
                  <span className="block w-6 h-0.5 bg-white transition-all duration-300" id="ham-1"></span>
                  <span className="block w-6 h-0.5 bg-white transition-all duration-300" id="ham-2"></span>
                  <span className="block w-6 h-0.5 bg-white transition-all duration-300" id="ham-3"></span>
                </button>
            </div>
          </div>
        </div>
        <div id="mobile-menu" className="hidden md:hidden bg-black/95 backdrop-blur-xl border-t border-zinc-800">
          <nav className="flex flex-col px-6 py-6 gap-5 font-inter">
            <div>
              <button type="button" id="mobile-solutions-toggle" className="flex items-center justify-between w-full text-zinc-300 hover:text-white transition-colors text-base">
                  Solutions
                  <svg id="mobile-solutions-arrow" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="transition-transform duration-200">
                    <path d="m6 9 6 6 6-6"></path>
                  </svg>
                </button>
              <div id="mobile-solutions-menu" className="hidden flex-col gap-2 mt-3 pl-4 border-l border-zinc-800">
                <a href="/fullstak" className="text-zinc-400 hover:text-white transition-colors text-sm py-1">FullStak</a>
                <a href="/in-house-agent" className="text-zinc-400 hover:text-white transition-colors text-sm py-1">In-House
                  Agent</a>
              </div>
            </div>
            <a href="/about-us" className="text-zinc-300 hover:text-white transition-colors text-base">About Us</a>
            <a href="/case-studies" className="text-zinc-300 hover:text-white transition-colors text-base">Case Studies</a>
            <a href="/contact-form" className="inline-flex items-center justify-center text-sm font-normal text-white bg-[#FE4C00] rounded-full py-3.5 px-8 mt-2">
              Get in Touch
            </a>
          </nav>
        </div>

      </header>

        <main className="flex-grow z-20 bg-black">


        <section className="overflow-hidden flex sm:pt-40 md:pt-48 md:pb-20 bg-zinc-950 border-zinc-900/50 border-b pt-32 pb-16 relative">
          <div className="sm:px-10 lg:px-16 z-10 w-full max-w-7xl mr-auto ml-auto px-6 relative">
            <div className="max-w-8xl text-center">
              <h1 className="leading-[1.05] sm:text-5xl md:text-6xl lg:text-8xl text-4xl font-medium text-white tracking-tight font-space-grotesk text-center mt-8">
                One Spark. Your Systems.
              </h1>
              <div className="inline-block mt-3 bg-[#FE4C00] px-5 sm:px-6 py-1 sm:py-0">
                <h1 className="leading-[1.05] sm:text-5xl md:text-6xl lg:text-8xl text-4xl font-medium text-white tracking-tight font-space-grotesk">
                  Infinite Scale.
                </h1>
              </div>
              <p className="leading-relaxed sm:text-xl text-base font-light text-zinc-300 font-inter text-center max-w-7xl mt-8 mb-10">
                We build Ai-run operations: faster output, higher standards, more capacity...<br className="hidden sm:block" /> without more headcount.
              </p>
              <a href="https://calendly.com/kindling-solutions/kindling-solutions" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center hover:bg-zinc-900 transition-colors sm:w-auto text-sm font-normal text-white font-inter bg-[#FE4C00] w-fit rounded-full pt-3.5 pr-8 pb-3.5 pl-8">
                Book a Call
              </a>
            </div>
          </div>
        </section>

        <section className="relative min-h-[400px] lg:min-h-[800px] overflow-hidden bg-black flex items-center">
        <video src="https://www.dropbox.com/scl/fi/gln4m543mujld7ql89w2f/creation_3222016501.mp4?rlkey=8u4798rha7tz77znwmx6z5se2&amp;st=dunmhyc1&amp;&amp;raw=1" autoPlay="" loop="" muted="" playsInline="" className="absolute inset-0 w-full h-full object-cover opacity-90" style={{"objectPosition": "30% 55%"}}></video>
        <div className="absolute inset-0 bg-black/0"></div>
        <div className="absolute inset-x-0 top-0 h-20 sm:inset-0 sm:h-auto bg-gradient-to-b from-black via-black/10 to-transparent">
        </div>
        <div className="relative z-10 w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
          <div className="flex flex-col items-center justify-center text-center gap-12"></div>
        </div>
      </section>


        <section className="animate-now sm:pb-0 sm:pt-24 bg-black border-zinc-900/50 border-b pt-24 pb-0 relative scale-break-section">
          <div className="text-center max-w-7xl mr-auto mb-4 ml-auto">

            <h2 className="md:text-6xl text-4xl font-medium text-white tracking-tight font-space-grotesk mt-6 mb-6">
              Scale
              <span className="inline-flex align-bottom text-[#FE4C00] mx-1 relative">
                  <span className="invisible" aria-hidden="true">breaks</span>
              <span className="split-word-top [clip-path:polygon(0_0,100%_0,100%_50%,0_50%)] font-medium font-space-grotesk w-full h-full absolute top-0 left-0 text-[#FE4C00]">breaks</span>
              <span className="split-word-line text-[#FE4C00] bg-white w-full h-[2px] rounded-full absolute top-1/2 left-0 shadow-[0_0_8px_rgba(255,255,255,0.8)]"></span>
              <span className="split-word-bottom [clip-path:polygon(0_50%,100%_50%,100%_100%,0_100%)] font-medium text-[#FE4C00] w-full h-full absolute top-0 left-0">breaks</span>
              </span>
              duct tape.
            </h2>
            <p className="text-lg sm:text-2xl font-light text-white font-inter">
              If work only moves when you're in the middle, you're the system.
            </p>
          </div>

        </section>


        <section className="overflow-visible z-10 bg-black max-w-7xl border-zinc-900/50 border-b mr-auto ml-auto pt-0 pr-6 pb-4 pl-6 relative">

          <div className="flex mt-32 z-20 relative justify-center">
            <div className="flex relative items-center justify-center">
              <div className="absolute -top-32 h-32 w-[2px] bg-gradient-to-b from-transparent via-[#FE4C00]/50 to-[#FE4C00] shadow-[0_0_20px_#FE4C00] overflow-hidden">
                <div className="absolute inset-0 bg-white/50 w-full h-1/2 animate-[scanner_2s_linear_infinite] blur-[2px]">
                </div>
              </div>
              <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-zinc-950 shadow-[0_0_50px_rgba(254,76,0,0.3)] border border-[#FE4C00]/30">
                <div className="absolute inset-[-10px] rounded-full border border-[#FE4C00]/20 border-dashed animate-[spin_10s_linear_infinite]">
                </div>
                <div className="absolute inset-[-4px] rounded-full border border-[#FE4C00]/30 border-dotted animate-[spin_15s_linear_infinite_reverse]">
                </div>
                <div className="absolute inset-0 rounded-full bg-[#FE4C00]/20 blur-xl animate-pulse"></div>
                <div className="relative z-10 animate-[pulse_3s_ease-in-out_infinite]">
                  <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/f965d3f0-25ae-426e-8843-d393473e2223_320w.png" alt="Custom Icon" className="drop-shadow-[0_0_10px_rgba(255,255,255,0.5)] w-[80px] h-[80px] object-contain" style={{"width": "80px", "height": "80px"}} />
                </div>
              </div>
            </div>
          </div>
          <div className="text-center max-w-7xl mx-auto mb-20 px-4 sm:px-6 lg:px-8">

            <h2 className="md:text-6xl text-4xl font-medium text-[#FE4C00] font-space-grotesk mt-8" style={{"animation": "slideInY 800ms ease-in-out 0ms forwards"}}>
              Stop being the system. Install one.
            </h2>
            <h2 className="md:text-6xl text-4xl font-medium text-white font-space-grotesk mb-10" style={{"animation": "slideInY 800ms ease-in-out 0ms forwards"}}>
              Built for how you actually operate.
            </h2>
            <div className="grid grid-cols-1 gap-y-8 gap-x-10 sm:grid-cols-2 lg:grid-cols-3 lg:gap-12">
              <div className="flex flex-col gap-y-4 items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{"color": "rgb(254, 76, 0)"}}>
                  <path d="M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z">
                  </path>
                  <path d="m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18">
                  </path>
                  <path d="m2.3 2.3 7.286 7.286"></path>
                  <circle cx="11" cy="11" r="2"></circle>
                </svg>

                <p className="leading-relaxed text-base sm:text-xl font-light text-white font-inter text-center">AI-run roles
                  built into the business (not random tools)</p>
              </div>
              <div className="flex flex-col gap-y-4 items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{"color": "rgb(254, 76, 0)"}}>
                  <rect width="8" height="8" x="3" y="3" rx="2"></rect>
                  <path d="M7 11v4a2 2 0 0 0 2 2h4"></path>
                  <rect width="8" height="8" x="13" y="13" rx="2"></rect>
                </svg>
                <p className="leading-relaxed text-base sm:text-xl font-light text-white font-inter text-center">Work completes
                  without constant human coordination</p>
              </div>
              <div className="flex flex-col gap-y-4 items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{"color": "rgb(254, 76, 0)"}} className="">
                  <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"></path>
                  <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"></path>
                  <path d="M7 21h10"></path>
                  <path d="M12 3v18"></path>
                  <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"></path>
                </svg>
                <p className="leading-relaxed text-base sm:text-xl font-light text-white font-inter text-center">Capacity scales
                  without hiring</p>
              </div>
            </div>
          </div>
        </section>


        <section className="relative bg-[#FE4C00] overflow-hidden" style={{"paddingTop": "7rem", "paddingBottom": "7rem"}}>
          <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
            <div className="text-center max-w-4xl mx-auto mb-4">
              <h2 className="text-5xl md:text-7xl font-medium text-white tracking-tight leading-[0.95] font-space-grotesk">Our
                Approach</h2>
              <p className="mt-6 text-xl md:text-2xl text-white/85 font-light font-inter">Stop adding work. Add capacity.</p>
            </div>

            <div className="approach-orbit relative mx-auto max-w-5xl flex items-center justify-center" style={{"minHeight": "720px"}}>
              <div className="absolute z-20 w-[260px] sm:w-[340px] text-center">
                <h3 id="approach-title" className="text-4xl sm:text-5xl font-medium text-white tracking-tight font-space-grotesk leading-none">Find leverage</h3>
                <p id="approach-copy" className="mt-5 text-base sm:text-lg font-light text-white/85 font-inter leading-relaxed">What to fix first + where AI creates outsized upside.</p>
              </div>

              <svg className="absolute w-[380px] h-[380px] sm:w-[620px] sm:h-[620px] max-w-[92vw] max-h-[92vw]" viewBox="0 0 620 620" fill="none">
                <circle cx="310" cy="310" r="238" stroke="rgba(0,0,0,0.22)" strokeWidth="1"></circle>
                <circle cx="310" cy="310" r="238" stroke="rgba(255,255,255,0.28)" strokeWidth="1" strokeDasharray="6 10">
                </circle>
                <circle className="approach-progress" cx="310" cy="310" r="238" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" transform="rotate(-90 310 310)" style={{"strokeDashoffset": "986"}}></circle>
                <circle cx="310" cy="72" r="7" fill="#000000"></circle>
                <circle cx="516" cy="429" r="7" fill="#000000"></circle>
                <circle cx="104" cy="429" r="7" fill="#000000"></circle>
                <g transform="translate(310,310)">
                  <g className="approach-dot">
                    <circle cx="0" cy="-238" r="10" fill="#000000"></circle>
                    <circle cx="0" cy="-238" r="20" fill="rgba(0,0,0,0.18)"></circle>
                  </g>
                </g>
              </svg>

              <button type="button" className="approach-step absolute top-[3%] left-1/2 -translate-x-1/2 active" data-title="Find leverage" data-copy="What to fix first + where AI creates outsized upside.">
              <span>01</span> Find leverage
            </button>
              <button type="button" className="approach-step absolute bottom-[15%] right-[6%]" data-title="Build your system" data-copy="Custom decisions, routing, and accountability — built around how you actually operate.">
              <span>02</span> Build your system
            </button>
              <button type="button" className="approach-step absolute bottom-[15%] left-[6%]" data-title="Put AI to work" data-copy="AI roles wired into your system, in production, until it runs without you.">
              <span>03</span> Put AI to work
            </button>
            </div>
          </div>




        </section>


        <section className="sm:py-32 bg-black z-10 pt-12 pb-16 relative">
          <div className="sm:px-6 lg:px-8 max-w-6xl mx-auto pr-8 pl-8">
            <div className="flex flex-row items-center justify-between mb-8 sm:mb-16 gap-4">
              <h2 className="md:text-7xl text-4xl font-medium text-white tracking-tight font-space-grotesk m-0" style={{"animation": "slideInY 800ms ease-in-out 0ms forwards"}}>Start Here</h2>
              <button className="hover:bg-[#CC0000] transition-all duration-300 cursor-pointer whitespace-nowrap text-sm sm:text-base font-medium text-white bg-[#FE4C00] w-fit rounded-full px-5 sm:px-8 py-3.5" data-aura-onclick="window.location.href='https://calendly.com/kindling-solutions/kindling-solutions'" role="button">Book a Call</button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 lg:gap-10 gap-x-8 gap-y-8 items-stretch">
              <div className="flex h-full">
                <a href="/FullStak" target="_self" data-aura-onclick="history.scrollRestoration='manual'; window.scrollTo(0,0);" style={{"boxShadow": "0 0 60px 10px rgba(254,76,0,0.3), 0 0 120px 20px rgba(255,255,255,0.06)", "textDecoration": "none"}} className="sm:p-12 flex flex-col z-10 transition-all duration-300 hover:scale-[1.02] w-full h-full rounded-3xl pt-8 pr-8 pb-8 pl-8 relative overflow-hidden bg-black">
                  <div className="bg-center bg-[url(https://images.unsplash.com/photo-1595418917831-ef942bd9f9ec?w=1600&amp;q=80)] bg-cover absolute top-0 right-0 bottom-0 left-0">
                  </div>
                  <div className="relative z-10">
                    <div className="flex-grow flex flex-col">
                      <div className="flex items-center gap-3 mb-16">
                        <p className="leading-tight sm:text-4xl text-2xl font-medium text-[#FE4C00] tracking-tight font-inter">
                          FullStak
                        </p>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{"color": "rgb(255, 255, 255)"}}>
                          <path d="M5 12h14"></path>
                          <path d="m12 5 7 7-7 7"></path>
                        </svg>
                      </div>
                      <p className="leading-tight sm:text-3xl text-xl font-normal text-white tracking-tight font-inter mb-8">We
                        build and install your custom <span className="font-bold">AI team</span> across the business.</p>
                      <p className="sm:text-xl leading-tight text-base font-normal text-white tracking-tight font-inter mb-8">Work
                        runs, quality goes up, and output scales without you in the middle.</p>
                    </div>
                  </div>
                </a>
              </div>
              <div className="flex flex-col h-full">
                <a href="/in-house-agent" target="_self" data-aura-onclick="history.scrollRestoration='manual'; window.scrollTo(0,0);" style={{"boxShadow": "0 0 60px 10px rgba(254,76,0,0.3), 0 0 120px 20px rgba(255,255,255,0.06)", "textDecoration": "none"}} className="sm:p-10 flex flex-col h-full transition-all duration-300 hover:scale-[1.02] bg-center bg-zinc-800 bg-[url(https://images.unsplash.com/photo-1595418917831-ef942bd9f9ec?w=1600&amp;q=80)] bg-cover rounded-3xl pt-8 pr-8 pb-8 pl-8 relative">
                  <div className="flex items-center gap-3 mb-16">
                    <p className="leading-tight sm:text-4xl text-2xl font-medium text-[#FE4C00] tracking-tight font-inter">
                      In-House Agent
                    </p>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{"color": "rgb(255, 255, 255)"}}>
                      <path d="M5 12h14"></path>
                      <path d="m12 5 7 7-7 7"></path>
                    </svg>
                  </div>
                  <div className="">
                    <p className="sm:text-3xl leading-snug text-xl font-normal text-white font-inter mb-8">Want to start small?
                      <span className="font-bold">One AI role</span> installed to solve one defined problem—fast.
                    </p>
                    <p className="sm:text-xl leading-tight text-base font-normal text-white tracking-tight font-inter">One job
                      gets
                      done reliably, on a rhythm, without you babysitting it.</p>
                    <div className="mt-10 px-2 flex flex-col items-start"></div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </section>


        <section className="relative bg-black border-t border-zinc-900/50 overflow-hidden z-10">
          <div className="absolute inset-0 z-0">
            <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/11b56623-2d13-48c7-8d18-f1b905e6be2b_3840w.png" className="w-full h-full object-cover opacity-70" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-transparent"></div>
          </div>
          <div className="sm:px-6 lg:px-8 sm:py-32 max-w-max z-10 mr-auto ml-auto pt-24 pr-4 pb-24 pl-4 relative">
            <div className="fade-up-element mb-12">
              <h2 className="sm:text-6xl text-4xl font-medium text-white tracking-tight font-space-grotesk mb-4">Results, not
                rhetoric</h2>
              <p className="text-base sm:text-lg font-light text-zinc-300">Some results Kindling clients have experienced:</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 max-w-6xl gap-x-4 gap-y-4">

              <div className="sm:p-8 bg-zinc-900/20 border border-zinc-700/60 rounded-2xl px-6 py-6 backdrop-blur-md transition-all duration-300 ease-out hover:scale-105 hover:shadow-2xl hover:shadow-black/50 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.08)]">
                <div className="text-5xl sm:text-6xl font-bold text-[#FE4C00] tracking-tight font-grotesk mb-4">10-15</div>
                <p className="text-base font-medium text-white leading-tight mb-1">hours/week eliminated</p>
                <p className="text-base font-light text-zinc-300 leading-tight">by removing manual coordination</p>
              </div>
              <div className="sm:p-8 bg-zinc-900/20 border border-zinc-700/60 rounded-2xl px-6 py-6 backdrop-blur-md transition-all duration-300 ease-out hover:scale-105 hover:shadow-2xl hover:shadow-black/50 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.08)]">
                <div className="text-5xl sm:text-6xl font-bold text-[#FE4C00] tracking-tight font-grotesk mb-4">20%</div>
                <p className="text-base text-white leading-tight">
                  <span className="font-medium text-[#FE4C00]">month-over-month growth</span>
                  <span className="font-light text-zinc-100"> after installing systems that made follow-up consistent.</span>
                </p>
              </div>
              <div className="bg-[#FE4C00] rounded-2xl p-6 sm:p-8 transition-all duration-300 ease-out hover:scale-105 hover:shadow-2xl hover:shadow-black/50">
                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0" style={{"color": "rgb(0, 0, 0)"}}>
                  <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"></path>
                  <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" className="">
                  </path>
                  <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"></path>
                  <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"></path>
                  <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"></path>
                  <path d="M3.477 10.896a4 4 0 0 1 .585-.396"></path>
                  <path d="M19.938 10.5a4 4 0 0 1 .585.396"></path>
                  <path d="M6 18a4 4 0 0 1-1.967-.516"></path>
                  <path d="M19.967 17.484A4 4 0 0 1 18 18"></path>
                </svg>
                <p className="leading-tight text-lg sm:text-xl font-semibold text-white mt-4 mb-4">The business stopped living
                  in one person's head</p>
                <p className="text-sm font-light text-white/90 leading-relaxed">Clear process + accountability the team can
                  actually run.</p>
              </div>
            </div>
          </div>
        </section>


        <section className="sm:py-32 bg-black z-10 pt-24 pb-24 relative">
          <div className="sm:px-6 lg:px-8 max-w-7xl z-30 mr-auto ml-auto pr-4 pl-4 relative">
            <h2 className="leading-tight typography-reveal sm:text-5xl lg:text-6xl text-4xl font-normal text-white tracking-tight font-grotesk">
              <span className="overflow-hidden inline-block align-bottom pb-1 -mb-1">
                  <span className="reveal-text inline-block font-medium text-[#FE4C00]">This is the leverage shift.</span>
              </span>
              <br className="hidden sm:block" />
            </h2>
            <div className="sm:text-2xl leading-relaxed text-lg font-light text-zinc-300 font-sans max-w-7xl space-y-8">
              <p className="fade-up-element font-inter max-w-7xl mt-4">More customers. More moving parts. More "quick
                questions." Work only moves when someone pushes it.</p>
              <p className="fade-up-element font-inter max-w-7xl">AI breaks that constraint—when it's built into how
                you work. Not as more tools. As the system behind the work. Work completes itself. Visibility goes
                real-time. Output scales without headcount.</p>
              <p className="fade-up-element font-normal text-[#FE4C00] tracking-tight font-inter">

                Digital had winners. The internet had winners. Mobile had winners. AI will too. AI changes the rules of
                scale. The gap widens every week.
              </p>
            </div>
          </div>
        </section>


        <section className="lg:py-20 flex min-h-[160px] z-20 bg-black border-zinc-900 border-t pt-16 pb-16 relative items-center">
          <div className="absolute -top-48 sm:-top-64 inset-x-0 bottom-0 z-0 pointer-events-none" style={{"maskImage": "linear-gradient(to bottom, transparent, black 50%, black 100%)", "WebkitMaskImage": "linear-gradient(to bottom, transparent, black 50%, black 100%)"}}>
            <video autoPlay="" loop="" muted="" playsInline="" className="w-full h-full object-cover opacity-[0.65]">
              <source src="https://www.dropbox.com/scl/fi/w9nevz50tma7ffb3en1jh/freepik_guy-in-vr-goggles-looking_2802940161.mp4?rlkey=fyfw1rue0iwmqtihbehkbqxtq&amp;st=cd0lkv5e&amp;raw=1" type="video/mp4" />
            </video>
            <div className="absolute inset-0 bg-black/35"></div>
          </div>
          <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col xl:flex-row gap-12 xl:gap-8 gap-x-12 gap-y-12 items-center justify-between">
              <div className="flex-shrink-0 text-center xl:text-left w-full xl:w-auto">
                <h3 className="sm:text-3xl text-xl font-normal text-white tracking-tight font-inter pr-8">Trusted by the best:
                </h3>
              </div>
              <div className="w-full overflow-hidden flex items-center relative py-6" style={{"WebkitMaskImage": "linear-gradient(to right, transparent, black 15%, black 85%, transparent)", "maskImage": "linear-gradient(to right, transparent, black 15%, black 85%, transparent)"}}>

                <div className="flex animate-marquee items-center gap-x-16 sm:gap-x-24 opacity-90">
                  <div className="lowercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight font-montserrat flex-shrink-0" data-aura-onclick="window.location.href='https://www.xerox.com/en-us'" role="button">Xerox</div>
                  <div className="lowercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight font-jakarta flex-shrink-0" data-aura-onclick="window.location.href='https://squlptbody.com'" role="button">squlpt</div>
                  <div className="uppercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight font-playfair flex-shrink-0" data-aura-onclick="window.location.href='https://www.johnwcrow.com'" role="button">CROW</div>
                  <div className="lowercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight flex-shrink-0" data-aura-onclick="window.location.href='https://www.sheepisblack.com'" role="button">blacksheep</div>
                  <div className="flex items-center gap-2 sm:gap-4 cursor-pointer flex-shrink-0" data-aura-onclick="window.location.href='https://www.spray-net.com'" role="button">
                    <svg className="h-12 w-12 sm:h-16 sm:w-16 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="M2.5 12 L20 5"></path>
                      <path d="M2.5 12 L21.5 10"></path>
                      <path d="M2.5 12 L21.5 14"></path>
                      <path d="M2.5 12 L20 19"></path>
                      <path d="M2.5 12 L17 21"></path>
                      <path d="M2.5 12 L17 3"></path>
                    </svg>
                    <span className="font-medium text-3xl sm:text-4xl tracking-tight text-white uppercase">Spray•Net</span>
                  </div>
                  <div className="text-[54px] sm:text-6xl font-bold text-white lowercase tracking-tight flex-shrink-0" style={{"letterSpacing": "-0.08em"}} data-aura-onclick="window.location.href='https://www.aspbranding.com'" role="button">
                    asp</div>
                  <div className="flex flex-col text-white uppercase justify-center cursor-pointer flex-shrink-0" data-aura-onclick="window.location.href='https://throughtheleash.com'" role="button">
                    <span className="text-sm sm:text-base font-medium tracking-wide">Through the</span>
                    <span className="leading-none border-b-[4px] sm:pb-0 text-4xl sm:text-5xl font-bold tracking-tight border-white pb-1.5">Leash</span>
                  </div>

                  <div className="lowercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight font-montserrat flex-shrink-0" data-aura-onclick="window.location.href='https://www.xerox.com/en-us'" role="button">Xerox</div>
                  <div className="lowercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight font-jakarta flex-shrink-0" data-aura-onclick="window.location.href='https://squlptbody.com'" role="button">squlpt</div>
                  <div className="uppercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight font-playfair flex-shrink-0" data-aura-onclick="window.location.href='https://www.johnwcrow.com'" role="button">CROW</div>
                  <div className="lowercase cursor-pointer text-4xl sm:text-5xl font-medium text-white tracking-tight flex-shrink-0" data-aura-onclick="window.location.href='https://www.sheepisblack.com'" role="button">blacksheep</div>
                  <div className="flex items-center gap-2 sm:gap-4 cursor-pointer flex-shrink-0" data-aura-onclick="window.location.href='https://www.spray-net.com'" role="button">
                    <svg className="h-12 w-12 sm:h-16 sm:w-16 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="M2.5 12 L20 5"></path>
                      <path d="M2.5 12 L21.5 10"></path>
                      <path d="M2.5 12 L21.5 14"></path>
                      <path d="M2.5 12 L20 19"></path>
                      <path d="M2.5 12 L17 21"></path>
                      <path d="M2.5 12 L17 3"></path>
                    </svg>
                    <span className="font-medium text-3xl sm:text-4xl tracking-tight text-white uppercase">Spray•Net</span>
                  </div>
                  <div className="text-[54px] sm:text-6xl font-bold text-white lowercase tracking-tight flex-shrink-0" style={{"letterSpacing": "-0.08em"}} data-aura-onclick="window.location.href='https://www.aspbranding.com'" role="button">
                    asp</div>
                  <div className="flex flex-col text-white uppercase justify-center cursor-pointer flex-shrink-0" data-aura-onclick="window.location.href='https://throughtheleash.com'" role="button">
                    <span className="text-sm sm:text-base font-medium tracking-wide">Through the</span>
                    <span className="leading-none border-b-[4px] sm:pb-0 text-4xl sm:text-5xl font-bold tracking-tight border-white pb-1.5">Leash</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>


        <section className="bg-black border-zinc-900 border-t pt-24 pb-24 relative overflow-hidden z-10">
          <div className="sm:px-6 lg:px-8 z-10 max-w-7xl mr-auto ml-auto pr-4 pl-4 relative">
            <div className="flex flex-col lg:flex-row gap-10 fade-up-element mb-0 gap-x-10 gap-y-10 items-start justify-between">
              <h2 className="text-4xl font-medium tracking-tight text-white max-w-3xl leading-tight font-grotesk sm:text-6xl">
                <span className="text-[#FE4C00]">What we build.</span> In the wild.
              </h2>
            </div>
            <div className="flex flex-col lg:flex-row gap-10 fade-up-element mb-16 gap-x-10 gap-y-10 items-start justify-between">
              <h2 className="leading-tight text-base sm:text-xl font-medium text-white tracking-tight font-grotesk max-w-3xl">
                Some highlighted case studies:
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 fade-up-element gap-x-4 gap-y-4">
              <a href="/case-studies#xerox" className="flex flex-col hover:border-zinc-700 transition-colors bg-zinc-700/40 h-[280px] sm:h-[420px] border-zinc-800/50 border rounded-3xl pt-0 pr-8 pb-8 pl-8 backdrop-blur-md justify-between">
                <div className="flex pt-6 items-center justify-between">
                  <div className="flex gap-3 items-center">
                    <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/f1effcd7-271a-45bb-bcb1-c46652da778c_320w.jpg" alt="User" className="w-10 h-10 rounded-full object-cover grayscale border border-zinc-700" />
                    <div className="text-sm font-medium text-white leading-none font-grotesk">Xerox</div>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{"color": "rgb(255, 255, 255)"}}>
                    <path d="M5 12h14"></path>
                    <path d="m12 5 7 7-7 7"></path>
                  </svg>
                </div>
                <div className="">
                  <h3 className="leading-tight text-xl font-medium text-white tracking-tight font-grotesk mb-20 pb-0">Billing that
                    matches reality.</h3>
                  <p className="text-zinc-400 leading-relaxed text-base font-light font-inter">Installs become billable
                    automatically—so invoice prep drops to minutes.</p>
                </div>
              </a>
              <a href="/case-studies#crow" className="flex flex-col hover:border-zinc-700 transition-colors bg-zinc-700/40 h-[280px] sm:h-[420px] border-zinc-800/50 border rounded-3xl pt-0 pr-8 pb-8 pl-8 backdrop-blur-md justify-between no-underline">
                <div className="flex pt-6 items-center justify-between">
                  <div className="flex gap-3 items-center">
                    <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/7db84f60-1d18-48fb-9287-aa8597dbcb7b_320w.jpg" alt="User" className="w-10 h-10 rounded-full object-cover grayscale border border-zinc-700" />
                    <div className="text-sm font-medium text-white leading-snug font-grotesk">Crow Estate<br />Planning &amp; Probate
                    </div>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{"color": "rgb(255, 255, 255)"}}>
                    <path d="M5 12h14"></path>
                    <path d="m12 5 7 7-7 7"></path>
                  </svg>
                </div>
                <div className="">
                  <h3 className="leading-tight text-xl font-medium text-white tracking-tight font-grotesk mb-8">AI-run case
                    management
                    without the scavenger hunt.</h3>
                  <p className="text-zinc-400 leading-relaxed text-base font-light font-inter">One system for cases,
                    communication,
                    tasks, and documents—so nothing slips and attorneys aren't exposed.</p>
                </div>
              </a>
              <a href="/case-studies#squlpt" className="flex flex-col hover:border-zinc-700 transition-colors bg-zinc-700/40 h-[280px] sm:h-[420px] border-zinc-800/50 border rounded-3xl pt-0 pr-8 pb-8 pl-8 backdrop-blur-md justify-between no-underline">
                <div className="flex pt-6 items-center justify-between">
                  <div className="flex gap-3 items-center">
                    <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/54571749-f1d2-4b32-9e2f-136640adae0d_320w.jpg" alt="User" className="w-10 h-10 rounded-full object-cover grayscale border border-zinc-700" />
                    <div className="text-sm font-medium text-white leading-none font-grotesk">Squlpt Body</div>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px] shrink-0" aria-hidden="true" style={{"color": "rgb(255, 255, 255)"}}>
                    <path d="M5 12h14"></path>
                    <path d="m12 5 7 7-7 7"></path>
                  </svg>
                </div>
                <div className="">
                  <h3 className="leading-tight text-xl font-medium text-white tracking-tight font-grotesk mb-14">A waiting room
                    that
                    runs itself.</h3>
                  <p className="text-zinc-400 leading-relaxed text-base font-light font-inter">Live queues, role-based dashboards,
                    and
                    automated reminders—so sessions move and utilization climbs.</p>
                </div>
              </a>
              <div className="flex flex-col overflow-hidden group bg-center text-white bg-stone-950 h-[280px] sm:h-[420px] bg-[url(https://images.unsplash.com/photo-1764946023990-2780e4905bb5?w=800&amp;q=80)] bg-cover border-zinc-800/100 border rounded-3xl pt-8 pr-8 pb-8 pl-8 relative justify-between" data-aura-onclick="window.location.href='/case-studies'" role="button">
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors duration-500" data-aura-onclick="window.location.href='/case-studies'" role="button"></div>
                <div className="absolute top-0 right-0 w-64 h-64 bg-[#FE4C00]/20 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2 group-hover:bg-[#FE4C00]/30 transition-colors duration-500">
                </div>
                <div className="flex text-white relative items-start justify-between">
                  <span className="text-lg font-medium tracking-tight font-grotesk">More Case Studies</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[24px] h-[24px]" aria-hidden="true" style={{"color": "rgb(255, 255, 255)"}}>
                    <path d="M5 12h14"></path>
                    <path d="m12 5 7 7-7 7"></path>
                  </svg>
                </div>
                <div className="relative z-10 mt-auto mb-8">
                  <p className="leading-relaxed text-base font-light text-white font-inter max-w-[260px] pb-12">See how operators
                    remove bottlenecks, install leverage, and scale without adding headcount.</p>
                </div>
                <div className="space-y-3 text-sm text-zinc-300 relative z-10 font-inter">
                  <a href="/case-studies" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center hover:bg-zinc-900 transition-colors sm:w-auto text-sm font-normal text-white font-inter bg-[#FE4C00] w-fit rounded-full pt-3.5 pr-8 pb-3.5 pl-8">Read
                    Case Studies</a>
                </div>
              </div>
            </div>
          </div>


          <section className="bg-black border-zinc-900 border-t pt-24 pb-24">
            <div className="sm:px-6 lg:px-8 max-w-7xl mr-auto ml-auto pr-4 pl-4">
              <div className="fade-up-element flex flex-col sm:flex-row sm:items-end gap-6 z-40 mb-16 relative gap-x-6 gap-y-6 items-start justify-between">
                <div className="">
                  <h2 className="sm:text-6xl text-4xl font-medium text-white tracking-tight font-grotesk mb-4">Why Kindling?</h2>
                  <p className="sm:text-xl text-base font-light text-zinc-400">Operator-built. Strategy-backed engineering.
                    Outcomes over theory.</p>
                </div>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="flex flex-col gap-4">
                  <div className="flex-1 sm:p-8 flex fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 w-[70px] h-[70px]" style={{"color": "rgb(254, 76, 0)"}}>
                      <path d="M5 7v11a1 1 0 0 0 1 1h11"></path>
                      <path d="M5.293 18.707 11 13"></path>
                      <circle cx="19" cy="19" r="2"></circle>
                      <circle cx="5" cy="5" r="2"></circle>
                    </svg>
                    <p className="leading-tight text-lg sm:text-xl font-bold text-white font-sans">Built, led, and scaled 5
                      businesses</p>
                  </div>
                  <div className="flex-1 sm:p-8 flex gap-6 fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">

                    <span className="text-6xl sm:text-8xl font-bold text-[#FE4C00] tracking-tight font-inter">17</span>
                    <p className="leading-tight text-base sm:text-xl font-light text-white font-inter">Years leading companies
                      from startup to scale</p>
                  </div>
                  <div className="flex-1 sm:p-8 flex gap-6 fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
                    <p className="leading-tight text-lg sm:text-2xl font-bold text-[#FE4C00] font-inter">We don't sell advice. We
                      develop working systems.</p>
                  </div>
                </div>
                <div className="relative rounded-3xl overflow-hidden min-h-[400px] lg:min-h-full fade-up-element group border border-zinc-800/50">
                  <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/8d348428-4a26-439e-9abe-73272d1bc0a8_1600w.png" alt="Vintage and Modern Cars in Residential Garage" className="w-full h-full object-cover absolute inset-0 transition-transform duration-1000 group-hover:scale-105" />
                  <div className="transition-opacity duration-1000 group-hover:bg-black/20 bg-black/40 absolute top-0 right-0 bottom-0 left-0">
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-40 h-40 bg-[#FE4C00] animate-[spin_12s_linear_infinite]" style={{"WebkitMask": "url('https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png') center/contain no-repeat", "mask": "url('https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png') center/contain no-repeat"}}>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-4">
                  <div className="flex-1 flex fade-up-element min-h-[140px] sm:p-8 bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
                    <p className="leading-tight text-base sm:text-xl font-light text-white font-inter">Three exits totaling</p>

                    <span className="text-6xl sm:text-8xl font-bold text-[#FE4C00] tracking-tight font-inter">$12B</span>
                  </div>
                  <div className="flex-1 sm:p-8 flex gap-6 fade-up-element min-h-[140px] bg-zinc-900/40 border-zinc-800/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6 gap-x-6 gap-y-6 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 w-[70px] h-[70px]" style={{"color": "rgb(254, 76, 0)"}}>
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path>
                      <path d="M12 18V6"></path>
                    </svg>
                    <p className="leading-tight text-lg sm:text-2xl font-bold text-white font-inter">8-, 9-, and 10-figure exits
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>


          <section className="bg-zinc-950/50 border-zinc-900 border-t pt-24 pb-4 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="fade-up-element flex flex-col sm:flex-row sm:items-end gap-6 z-40 mb-16 relative gap-x-6 gap-y-6 items-start justify-between">
                <div className="">
                  <h2 className="sm:text-6xl text-4xl font-medium text-[#FE4C00] tracking-tight font-grotesk mb-4">Trusted by
                    businesses</h2>
                  <h2 className="sm:text-6xl text-4xl font-medium text-white tracking-tight font-grotesk mb-4">around the world.
                  </h2>
                  <p className="text-base sm:text-lg text-zinc-400 font-light">Hear from the partners we've helped scale.</p>
                </div>
              </div>
              <div className="flex flex-col sm:gap-24 pb-[5vh] relative gap-x-12 gap-y-12">
                <div className="testimonial-sticky sticky top-24 z-10 w-full">
                  <div className="testimonial-inner w-full relative z-10" style={{"filter": "brightness(1)"}}>
                    <div className="absolute -top-16 -left-10 sm:-top-24 sm:-left-20 w-[300px] h-[300px] sm:w-[500px] sm:h-[500px] bg-[#FE4C00] rounded-full blur-[100px] sm:blur-[120px] opacity-30 pointer-events-none z-0">
                    </div>
                    <div className="absolute -bottom-12 right-6 sm:-bottom-20 sm:right-16 w-48 sm:w-[280px] z-0 pointer-events-none drop-shadow-[0_10px_30px_rgba(254,76,0,0.2)] translate-y-[20%]">
                      <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5782a90f-3351-458e-b20b-e4b0a099d529_800w.png" alt="Orange Quote Marks" className="w-full h-auto opacity-100" />
                    </div>
                    <div className="absolute inset-0 bg-zinc-950/60 backdrop-blur-[60px] rounded-3xl sm:rounded-[2rem] border border-zinc-700/50 shadow-2xl z-10">
                    </div>
                    <div className="sm:p-12 flex flex-col sm:gap-14 z-20 pt-8 pr-8 pb-8 pl-8 relative gap-x-10 gap-y-10">
                      <div className="flex items-center justify-between w-full">
                        <span className="font-grotesk text-[#FE4C00] text-sm font-semibold uppercase tracking-widest">Client's Testimonial</span>
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-12 lg:gap-16 gap-x-10 gap-y-10">
                        <div className="lg:col-span-4 flex flex-col h-full">
                          <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-start gap-6 sm:gap-8">
                            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden flex-shrink-0 border border-zinc-800">
                              <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/e0c9e981-4181-4858-920f-e00abb098e87_320w.jpg" alt="Chris Stevenson" className="w-full h-full object-cover grayscale" />
                            </div>
                            <div className="flex flex-col gap-1">
                              <h3 className="sm:text-4xl leading-none text-2xl font-medium text-[#FE4C00] tracking-tight font-grotesk">
                                Chris Stevenson</h3>
                              <span className="sm:text-lg sm:mt-2 text-sm font-light text-white font-sans mt-1">Founder &amp; Creative Director, Black Sheep Creative</span>
                            </div>
                          </div>
                        </div>
                        <div className="lg:col-span-8 flex flex-col sm:gap-12 sm:pb-0 pb-8 gap-x-8 gap-y-8">
                          <div className="flex flex-col gap-6 max-w-2xl font-light">

                            <p className="leading-relaxed text-xl text-zinc-300 font-sans sm:text-2xl">
                              "Before Kindling, I was stuck in AI overwhelm—wasting days comparing tools and still not
                              producing better work. Kindling helped me implement AI workflows that fit how I work, and I cut
                              my workload by about 75% while delivering my best work in a fraction of the time. Kindling
                              didn't just speed me up—it transformed my business."
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="testimonial-sticky sticky top-32 z-20 w-full">
                  <div className="testimonial-inner grid grid-cols-1 md:grid-cols-2 lg:gap-12 w-full backdrop-blur gap-x-8 gap-y-8" style={{"filter": "brightness(1)"}}>
                    <div className="group h-full">
                      <div className="sm:p-10 group-hover:border-zinc-700 transition-colors flex flex-col bg-zinc-900/60 h-full border-zinc-800/80 border rounded-2xl px-8 py-8 relative shadow-2xl backdrop-blur-lg">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-10 h-10 text-zinc-700 mb-6">
                          <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z">
                          </path>
                          <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z">
                          </path>
                        </svg>
                        <p className="sm:text-2xl leading-relaxed flex-grow text-xl font-light text-zinc-300 font-sans">
                          "Everything lived in my head—lead response was slow and follow-up was inconsistent. After the
                          Blueprint and implementation, we eliminated 10–15 hours/week of manual work and grew 20% month over
                          month."
                        </p>
                        <div className="flex border-zinc-800/50 border-t mt-10 pt-6 gap-x-4 gap-y-4 items-center">
                          <div className="h-12 w-12 rounded-full bg-zinc-800 overflow-hidden flex-shrink-0 border border-zinc-700/50">
                            <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/0dcdd895-28af-4d5d-87be-b6281ddcffd2_320w.png" alt="Steve Urbanski" className="opacity-80 w-full h-full object-cover grayscale" />
                          </div>
                          <div className="">
                            <h3 className="group-hover:text-zinc-300 transition-colors text-base font-normal text-white tracking-tight font-grotesk mb-1">
                              Steve Urbanski</h3>
                            <p className="sm:text-sm uppercase text-xs font-normal text-zinc-500 tracking-widest font-pixel">
                              Owner, Through the Leash</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="group h-full">
                      <div className="sm:p-10 group-hover:border-zinc-700 transition-colors flex flex-col bg-zinc-900/60 h-full border-zinc-800/80 border rounded-2xl pt-8 pr-8 pb-8 pl-8 relative shadow-2xl backdrop-blur-md">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-10 h-10 text-zinc-700 mb-6">
                          <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z">
                          </path>
                          <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z">
                          </path>
                        </svg>
                        <p className="sm:text-2xl leading-relaxed flex-grow text-xl font-light text-zinc-300 font-sans">
                          "Before Kindling, I was the system—and that's not a system, it's a liability. Now the business has a
                          brain outside of me, and I'm spending less time being the answer to every question."
                        </p>
                        <div className="flex items-center gap-4 mt-10 pt-6 border-t border-zinc-800/50">
                          <div className="h-12 w-12 rounded-full bg-zinc-800 overflow-hidden flex-shrink-0 border border-zinc-700/50">
                            <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/b1005be2-22ee-4d22-a288-9eafac19a3a7_320w.png" alt="Peter Straub" className="opacity-80 w-full h-full object-cover grayscale" />
                          </div>
                          <div className="">
                            <h3 className="group-hover:text-zinc-300 transition-colors text-base font-normal text-white tracking-tight font-grotesk mb-1">
                              Peter Straub</h3>
                            <p className="sm:text-sm uppercase text-xs font-normal text-zinc-500 tracking-widest font-pixel">
                              Franchise Partner, SprayNet</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="testimonial-sticky sticky top-40 z-30 w-full"></div>
              </div>
            </div>
          </section>


          <div className="sm:px-6 lg:px-8 z-10 text-center max-w-7xl mr-auto ml-auto pr-4 pl-4 relative">
            <div className="fade-up-element flex flex-col sm:flex-row gap-x-4 gap-y-4 items-center justify-center">
              <a href="https://calendly.com/kindling-solutions/kindling-solutions" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center hover:bg-zinc-900 transition-colors sm:w-auto text-sm font-normal text-white font-inter bg-[#FE4C00] w-fit rounded-full pt-3.5 pr-8 pb-3.5 pl-8">
                Book a Call
              </a>
            </div>
            <p className="leading-relaxed typography-reveal sm:text-2xl text-base text-zinc-300 text-center max-w-5xl mr-auto mb-12 ml-auto">
              <span className="overflow-hidden inline-block align-bottom -mb-1 font-inter max-w-6xl pt-0 pb-0">
                <span className="reveal-text inline-block font-inter max-w-6xl mt-8">We'll confirm fit, then map the highest-leverage implementation path.</span>
              </span>
            </p>
          </div>


          <section className="sm:pb-12 z-40 bg-black border-zinc-900 border-t pt-24 pb-8 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="fade-up-element rounded-2xl sm:rounded-3xl overflow-hidden border border-zinc-800/50">
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/c18e3593-27b3-4df7-82f6-35fdb9b26ebb_1600w.png" alt="Ignite Whats Next Keyboard Keys Banner" className="w-full h-auto object-cover" />
              </div>
            </div>
          </section>


          <section className="pb-24 pt-8 sm:pt-12 bg-black relative z-40">
            <div className="sm:px-6 lg:px-8 max-w-6xl mr-auto ml-auto pr-4 pl-4">
              <div className="fade-up-element text-center mb-16">
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/0547f70f-43a3-4916-98fd-dab34ad57238_320w.png" alt="Orange Message Bubble Icon" className="w-[4.2rem] sm:w-[4.8rem] h-auto mx-auto mb-6 animate-bounce" />
                <h2 className="sm:text-4xl text-3xl font-medium text-white tracking-tight font-inter mb-4">Frequently Asked
                  Questions</h2>
                <p className="sm:text-xl text-base font-light text-zinc-400">Everything you need to know about partnering with us.
                </p>
              </div>
              <div className="divide-y divide-zinc-800/70 border-y border-zinc-800/70">
                <details className="fade-up-element group first:pt-6 last:pb-6 pt-6 pb-6">
                  <summary className="flex items-center justify-between cursor-pointer list-none text-zinc-200 hover:text-white transition-colors focus:outline-none">
                    <span className="text-base sm:text-lg font-normal tracking-tight font-grotesk">Is this just "AI tools"?</span>
                    <span className="flex-shrink-0 ml-4 flex items-center justify-center h-6 w-6 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 group-open:rotate-180 transition-transform duration-300"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content leading-relaxed text-base font-light text-zinc-400 pt-4 pr-8 pb-2">No. Tools
                    don't scale a business—systems do. We don't sell prompts or a pile of subscriptions. We build the
                    operating layer that makes AI useful inside the work.</div>
                </details>
                <details className="fade-up-element group py-5">
                  <summary className="flex cursor-pointer list-none hover:text-white transition-colors focus:outline-none text-zinc-200 items-center justify-between">
                    <span className="text-base sm:text-lg font-normal tracking-tight font-grotesk">What do you actually deliver?</span>
                    <span className="flex-shrink-0 ml-4 flex items-center justify-center h-6 w-6 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 group-open:rotate-180 transition-transform duration-300"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content leading-relaxed text-base font-light text-zinc-400 pt-4 pr-8 pb-2">A working
                    system behind the work: how tasks get captured, routed, executed, checked, and shipped—plus AI where it
                    creates leverage. That usually includes automation, AI agents, dashboards/visibility, and the standards +
                    accountability so it doesn't fall apart after week two.</div>
                </details>
                <details className="fade-up-element group pt-5 pb-5">
                  <summary className="flex cursor-pointer list-none hover:text-white transition-colors focus:outline-none text-zinc-200 items-center justify-between">
                    <span className="text-base sm:text-lg font-normal tracking-tight font-grotesk">What happens on the first call?</span>
                    <span className="flex-shrink-0 flex items-center justify-center group-hover:text-zinc-300 transition-colors text-zinc-500 w-6 h-6 ml-4">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="group-open:rotate-180 transition-transform duration-300 w-[24px] h-[24px]"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content leading-relaxed text-base font-light text-zinc-400 pt-4 pr-8 pb-2">We diagnose
                    the constraint, show you the highest-leverage system to build first, and give you clear next steps. If
                    there's a fit, we scope the fastest path to install it.</div>
                </details>
                <details className="fade-up-element group py-5">
                  <summary className="flex items-center justify-between cursor-pointer list-none text-zinc-200 hover:text-white transition-colors focus:outline-none">
                    <span className="text-base sm:text-lg font-normal tracking-tight font-grotesk">How do we start?</span>
                    <span className="flex-shrink-0 ml-4 flex items-center justify-center h-6 w-6 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="group-open:rotate-180 transition-transform duration-300 w-[24px] h-[24px]"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content pt-4 pb-2 text-base text-zinc-400 leading-relaxed pr-8 font-light">We start
                    with
                    a diagnostic Blueprint to map how work actually moves, find the constraint, and outline the
                    highest-leverage
                    system to build first. Then we scope the custom build from there.</div>
                </details>
                <details className="fade-up-element group last:pb-6 pt-5 pb-6">
                  <summary className="flex items-center justify-between cursor-pointer list-none text-zinc-200 hover:text-white transition-colors focus:outline-none">
                    <span className="font-grotesk text-base sm:text-lg font-normal tracking-tight">What does it cost?</span>
                    <span className="flex-shrink-0 ml-4 flex items-center justify-center h-6 w-6 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 group-open:rotate-180 transition-transform duration-300"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content pt-4 pb-2 text-base text-zinc-400 leading-relaxed pr-8 font-light">We start
                    with
                    the Blueprint (21 days • $5K) to map how work actually moves, find the constraint, and define what to
                    build
                    first. From there, we scope FullStak to your needs—only what's required, no more, no less.</div>
                </details>
                <details className="fade-up-element group last:pb-6 pt-5 pb-6">
                  <summary className="flex cursor-pointer list-none hover:text-white transition-colors focus:outline-none text-zinc-200 items-center justify-between">
                    <span className="text-base sm:text-lg font-normal tracking-tight font-grotesk">How do you work with our current tools?</span>
                    <span className="flex-shrink-0 ml-4 flex items-center justify-center h-6 w-6 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 group-open:rotate-180 transition-transform duration-300"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content leading-relaxed text-base font-light text-zinc-400 pt-4 pr-8 pb-2">We build
                    around what you already use. If a tool stays, we integrate it. If a tool is the bottleneck, we replace
                    it—but only when the math is obvious.</div>
                </details>
                <details className="fade-up-element group last:pb-6 pt-5 pb-6">
                  <summary className="flex cursor-pointer list-none hover:text-white transition-colors focus:outline-none text-zinc-200 items-center justify-between">
                    <span className="text-base sm:text-lg font-normal tracking-tight font-grotesk">How fast will we see impact?</span>
                    <span className="flex-shrink-0 ml-4 flex items-center justify-center h-6 w-6 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 group-open:rotate-180 transition-transform duration-300"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content leading-relaxed text-base font-light text-zinc-400 pt-4 pr-8 pb-2">You'll see
                    early wins in weeks—faster follow-up, cleaner handoffs, fewer "where is this?" pings. Then it compounds as
                    more of the business runs through the system.</div>
                </details>
                <details className="fade-up-element group last:pb-6 pt-5 pb-6">
                  <summary className="flex cursor-pointer list-none hover:text-white transition-colors focus:outline-none text-zinc-200 items-center justify-between">
                    <span className="text-base sm:text-lg font-normal tracking-tight font-grotesk">Do we need to be technical?</span>
                    <span className="flex-shrink-0 ml-4 flex items-center justify-center h-6 w-6 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="group-open:rotate-180 transition-transform duration-300 w-[24px] h-[24px]"><path d="m6 9 6 6 6-6"></path></svg>
                    </span>
                  </summary>
                  <div className="accordion-content leading-relaxed text-base font-light text-zinc-400 pt-4 pr-8 pb-2">No. This
                    isn't a course. We implement with you, train your team on how the system runs, and make sure someone
                    internal can own it.</div>
                </details>
              </div>
            </div>
          </section>


          <section className="overflow-hidden flex whitespace-nowrap border-y bg-[#FE4C00] border-[#FE4C00] pt-5 pb-5">
            <div className="flex w-max items-center" style={{"animation": "scrollMarquee 40s linear infinite"}}>
              <div className="flex shrink-0 font-medium font-space-grotesk pr-12 gap-x-12 gap-y-12 items-center">
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
                <span className="font-space-grotesk text-2xl md:text-3xl font-semibold tracking-normal text-black uppercase">One Spark. Your Systems. Infinite Scale.</span>
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
                <span className="font-space-grotesk text-2xl md:text-3xl font-semibold tracking-normal text-black uppercase">One Spark. Your Systems. Infinite Scale.</span>
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
                <span className="font-space-grotesk text-2xl md:text-3xl font-semibold tracking-normal text-black uppercase">One Spark. Your Systems. Infinite Scale.</span>
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
              </div>
              <div className="flex shrink-0 items-center gap-12 pr-12">
                <span className="font-space-grotesk text-2xl md:text-3xl font-semibold tracking-normal text-black uppercase">One Spark. Your Systems. Infinite Scale.</span>
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
                <span className="font-space-grotesk text-2xl md:text-3xl font-semibold tracking-normal text-black uppercase">One Spark. Your Systems. Infinite Scale.</span>
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
                <span className="font-space-grotesk text-2xl md:text-3xl font-semibold tracking-normal text-black uppercase">One Spark. Your Systems. Infinite Scale.</span>
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
                <span className="font-space-grotesk text-2xl md:text-3xl font-semibold tracking-normal text-black uppercase">One Spark. Your Systems. Infinite Scale.</span>
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/21a3a351-757d-4dc4-ac9e-be28def84fcb_320w.png" alt="Pinwheel Logo" className="w-[34px] h-[34px] object-contain" />
              </div>
            </div>
          </section>
        </section>
      </main>


        <footer className="bg-black z-40 border-zinc-900 border-t pt-20 pb-10 relative">
          <div className="sm:px-6 lg:px-8 max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-8 mb-16 gap-x-12 gap-y-12">
              <div className="md:col-span-6 lg:col-span-5">
                <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/bb846fe5-c422-46d6-b6c7-7729fedb2b5a_320w.png" alt="Kindling Solutions" className="-ml-2 w-auto h-16 rounded-sm mb-8" />
                <div className="flex flex-col gap-6 w-full font-sans mt-2">
                  <p className="leading-relaxed text-base font-light text-zinc-100 font-inter max-w-md">Join our newsletter and
                    stay updated on the latest trends in AI-Automation World.</p>
                  <form action="https://formspree.io/f/xwvdplkk" method="POST" className="flex w-full max-w-[400px] mt-2">
                    <input type="hidden" name="_subject" value="New Newsletter Signup" />
                    <input type="email" name="email" placeholder="Email Address" required="" className="flex-1 h-12 bg-white text-zinc-900 placeholder:text-zinc-400 placeholder:font-mono font-mono px-4 text-sm outline-none min-w-0 rounded-none border-none" />
                    <button type="submit" className="hover:bg-[#e64400] transition-colors whitespace-nowrap border-none focus:outline-none text-sm font-medium text-black font-inter bg-[#FE4C00] h-12 rounded-none pr-6 pl-6 cursor-pointer">SIGN-UP</button>
                  </form>
                </div>
              </div>
              <div className="md:col-span-3 lg:col-span-2 lg:col-start-8 font-inter">
                <h4 className="font-sans text-white text-lg font-normal mb-8">Social</h4>
                <ul className="space-y-5">
                  <li><a href="https://x.com/KindlingSpark" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">X</a>
                  </li>
                  <li><a href="https://www.facebook.com/kindlingsolutions/" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">Facebook</a>
                  </li>
                  <li><a href="https://www.youtube.com/@KindlingSolutions" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">YouTube</a>
                  </li>
                  <li><a href="https://www.linkedin.com/company/kindling-solutions/" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">LinkedIn</a>
                  </li>
                  <li><a href="https://www.instagram.com/kindlingsolutions/" className="hover:text-white transition-colors flex items-center gap-2 group text-base font-light text-zinc-400">Instagram</a>
                  </li>
                </ul>
              </div>
              <div className="md:col-span-3 lg:col-span-3">
                <h4 className="text-lg font-normal text-white font-inter mb-8">Get in touch</h4>
                <p className="leading-relaxed text-base font-light text-zinc-400 font-inter max-w-[280px] mb-8">Ready to start
                  your next project?<br />Let's build something extraordinary.</p>
                <a href="mailto:jason@kindlingsolutions.com" className="inline-flex items-center justify-center hover:bg-[#e64400] transition-colors hover:shadow-[0_0_30px_rgba(254,76,0,0.5)] text-sm font-normal text-white bg-[#FE4C00] rounded-full pt-3 pr-6 pb-3 pl-6 shadow-[0_0_20px_rgba(254,76,0,0.3)]">Email
                  us Here</a>
              </div>
            </div>
            <div className="pt-8 border-t border-zinc-900/80 flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-sm font-light text-zinc-500">© 2026 Kindling Solutions. All rights reserved.</p>
              <div className="flex items-center gap-6">
                <a href="#" className="text-zinc-500 hover:text-zinc-300 font-light text-sm transition-colors">Privacy Policy</a>
                <a href="#" className="text-zinc-500 hover:text-zinc-300 font-light text-sm transition-colors">Terms of
                  Service</a>
              </div>
            </div>
          </div>
        </footer>
    </div>
  );
}
